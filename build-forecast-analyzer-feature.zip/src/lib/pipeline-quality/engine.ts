// Pipeline Quality Scorer — answers "how healthy and strong is the pipeline?"
// This is deliberately independent of any forecast number: it never looks at
// target, commit, or best case. That question belongs to Forecast Analyzer™.

export interface PipelineQualityInput {
  openPipelineValue: number;
  numOpenOpportunities: number;
  earlyStageValue: number;
  midStageValue: number;
  lateStageValue: number;
  avgOpportunityAgeDays: number | null;
  avgSalesCycleDays: number | null;
  staleOpportunities: number | null;
  multiThreadedOpportunities: number | null;
}

export interface QualityDimension {
  id: string;
  name: string;
  status: "SCORED" | "INSUFFICIENT_EVIDENCE";
  score: number | null;
  weight: number;
  rationale: string;
}

export interface PipelineQualityResult {
  qualityScore: number | null;
  band: string | null;
  dimensions: QualityDimension[];
  stageMix: { early: number; mid: number; late: number };
  notes: string[];
}

function clamp(v: number, min: number, max: number) {
  return Math.min(max, Math.max(min, v));
}

export function scorePipelineQuality(input: PipelineQualityInput): PipelineQualityResult {
  const notes: string[] = [];
  const dims: QualityDimension[] = [];
  const stageSum = input.earlyStageValue + input.midStageValue + input.lateStageValue;

  if (Math.abs(stageSum - input.openPipelineValue) > Math.max(1, input.openPipelineValue * 0.02)) {
    notes.push(
      `Stage values sum to $${stageSum.toLocaleString()}, which does not reconcile with total open pipeline of $${input.openPipelineValue.toLocaleString()}. Stage Balance is scored against the stage sum, not the stated total.`,
    );
  }

  const early = stageSum > 0 ? (input.earlyStageValue / stageSum) * 100 : null;
  const late = stageSum > 0 ? (input.lateStageValue / stageSum) * 100 : null;
  if (early !== null && late !== null) {
    const balanceScore = clamp(100 - Math.abs(early - 35) * 1.2, 20, 100);
    dims.push({
      id: "stageBalance",
      name: "Stage Balance",
      status: "SCORED",
      score: Math.round(balanceScore),
      weight: 30,
      rationale: `Early-stage value is ${early.toFixed(1)}% of pipeline and late-stage is ${late.toFixed(1)}%. A heavily front-loaded or heavily back-loaded pipeline both carry structural risk.`,
    });
  } else {
    dims.push({ id: "stageBalance", name: "Stage Balance", status: "INSUFFICIENT_EVIDENCE", score: null, weight: 30, rationale: "Stage values not supplied." });
  }

  if (input.avgOpportunityAgeDays !== null && input.avgSalesCycleDays !== null && input.avgSalesCycleDays > 0) {
    const ratio = input.avgOpportunityAgeDays / input.avgSalesCycleDays;
    const score = ratio <= 1 ? 100 : clamp(100 - (ratio - 1) * 70, 10, 100);
    dims.push({
      id: "aging",
      name: "Aging Health",
      status: "SCORED",
      score: Math.round(score),
      weight: 25,
      rationale: `Average opportunity age is ${ratio.toFixed(2)}× the typical sales cycle.`,
    });
  } else {
    dims.push({ id: "aging", name: "Aging Health", status: "INSUFFICIENT_EVIDENCE", score: null, weight: 25, rationale: "Average opportunity age and/or average sales cycle not supplied." });
  }

  if (input.staleOpportunities !== null && input.numOpenOpportunities > 0) {
    const staleShare = (input.staleOpportunities / input.numOpenOpportunities) * 100;
    const score = clamp(100 - staleShare * 1.5, 0, 100);
    dims.push({
      id: "hygiene",
      name: "Pipeline Hygiene",
      status: "SCORED",
      score: Math.round(score),
      weight: 25,
      rationale: `${staleShare.toFixed(1)}% of open opportunities have had no activity in the last 30 days.`,
    });
  } else {
    dims.push({ id: "hygiene", name: "Pipeline Hygiene", status: "INSUFFICIENT_EVIDENCE", score: null, weight: 25, rationale: "Stale opportunity count not supplied." });
  }

  if (input.multiThreadedOpportunities !== null && input.numOpenOpportunities > 0) {
    const share = (input.multiThreadedOpportunities / input.numOpenOpportunities) * 100;
    dims.push({
      id: "engagement",
      name: "Engagement Depth",
      status: "SCORED",
      score: Math.round(clamp(share * 1.3, 0, 100)),
      weight: 20,
      rationale: `${share.toFixed(1)}% of open opportunities have more than one confirmed stakeholder engaged.`,
    });
  } else {
    dims.push({ id: "engagement", name: "Engagement Depth", status: "INSUFFICIENT_EVIDENCE", score: null, weight: 20, rationale: "Multi-threaded opportunity count not supplied." });
  }

  const scored = dims.filter((d) => d.status === "SCORED" && d.score !== null);
  const weight = scored.reduce((s, d) => s + d.weight, 0);
  const qualityScore = weight > 0 ? Math.round(scored.reduce((s, d) => s + (d.score as number) * d.weight, 0) / weight) : null;
  const band =
    qualityScore === null ? null : qualityScore >= 80 ? "Strong" : qualityScore >= 60 ? "Adequate" : qualityScore >= 40 ? "Weak" : "Poor";

  return {
    qualityScore,
    band,
    dimensions: dims,
    stageMix: { early: early ?? 0, mid: stageSum > 0 ? (input.midStageValue / stageSum) * 100 : 0, late: late ?? 0 },
    notes,
  };
}
