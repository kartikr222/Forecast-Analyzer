// Pipeline Leak Detector — answers "where is revenue leaking from the pipeline?"
// It measures stage-to-stage attrition on the deals currently moving through
// the funnel. It does not evaluate the forecast number itself — that is
// Forecast Analyzer's job.

export interface LeakStageInput {
  label: string;
  value: number;
}

export interface LeakDetectorInput {
  stages: LeakStageInput[]; // ordered, first = top of funnel, last = closed-won
}

export interface LeakTransition {
  fromLabel: string;
  toLabel: string;
  fromValue: number;
  toValue: number;
  retainedPct: number;
  leakedValue: number;
}

export interface LeakDetectorResult {
  transitions: LeakTransition[];
  biggestLeak: LeakTransition | null;
  overallConversionPct: number | null;
  totalLeaked: number;
}

export function detectPipelineLeaks(input: LeakDetectorInput): LeakDetectorResult {
  const transitions: LeakTransition[] = [];
  for (let i = 0; i < input.stages.length - 1; i++) {
    const from = input.stages[i];
    const to = input.stages[i + 1];
    const retainedPct = from.value > 0 ? (to.value / from.value) * 100 : 0;
    transitions.push({
      fromLabel: from.label,
      toLabel: to.label,
      fromValue: from.value,
      toValue: to.value,
      retainedPct,
      leakedValue: Math.max(from.value - to.value, 0),
    });
  }

  const biggestLeak =
    transitions.length > 0
      ? transitions.reduce((worst, t) => (t.leakedValue > worst.leakedValue ? t : worst), transitions[0])
      : null;

  const first = input.stages[0];
  const last = input.stages[input.stages.length - 1];
  const overallConversionPct = first && first.value > 0 ? (last.value / first.value) * 100 : null;
  const totalLeaked = transitions.reduce((s, t) => s + t.leakedValue, 0);

  return { transitions, biggestLeak, overallConversionPct, totalLeaked };
}
