import type { ForecastAnalyzerInput, DimensionResult, IntegrityIssue } from "./types";
import { clamp } from "./format";

/**
 * Ten diagnostic dimensions. Each is scored independently and deterministically
 * from the inputs actually supplied. If the inputs a dimension depends on are
 * missing, the dimension is marked INSUFFICIENT_EVIDENCE and excluded from the
 * weighted Forecast Reliability Score rather than assigned a fabricated midpoint.
 */
export function buildDimensions(
  input: ForecastAnalyzerInput,
  issues: IntegrityIssue[],
): DimensionResult[] {
  const dims: DimensionResult[] = [];
  const remainingForecast = Math.max(input.currentForecast - input.closedRevenue, 0);
  const remainingTarget = Math.max(input.revenueTarget - input.closedRevenue, 0);

  // 1. Evidence Strength (weight 12) — how much of the forecast is backed by
  // closed revenue (HIGH) and weighted pipeline (MEDIUM) vs. unweighted judgment (LOW).
  {
    const evidenceUsed = ["Closed revenue", "Current forecast"];
    if (input.weightedPipeline === null) {
      dims.push({
        id: "evidenceStrength",
        name: "Evidence Strength",
        question: "How much of the reported forecast is backed by measured evidence rather than judgment?",
        weight: 12,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale:
          input.currentForecast > 0
            ? `${((input.closedRevenue / input.currentForecast) * 100).toFixed(1)}% of the forecast is already closed and evidence-locked, but weighted pipeline was not supplied, so the medium-evidence layer covering the remaining ${remainingForecast.toLocaleString()} cannot be measured.`
            : "Current forecast is $0 — evidence composition cannot be assessed.",
        evidenceUsed,
        missingEvidence: "Weighted pipeline value for the current period.",
      });
    } else if (input.currentForecast <= 0) {
      dims.push({
        id: "evidenceStrength",
        name: "Evidence Strength",
        question: "How much of the reported forecast is backed by measured evidence rather than judgment?",
        weight: 12,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "Current forecast is $0 — there is no forecast to test evidence composition against.",
        evidenceUsed,
        missingEvidence: "A non-zero current forecast value.",
      });
    } else {
      const closedShare = remainingForecast === 0 ? 1 : input.closedRevenue / input.currentForecast;
      const coverageOfRemainder =
        remainingForecast === 0 ? 1 : clamp(input.weightedPipeline / remainingForecast, 0, 1);
      const score =
        remainingForecast === 0
          ? 100
          : clamp(closedShare * 100 * 0.4 + coverageOfRemainder * 100 * 0.6, 0, 100);
      dims.push({
        id: "evidenceStrength",
        name: "Evidence Strength",
        question: "How much of the reported forecast is backed by measured evidence rather than judgment?",
        weight: 12,
        status: "SCORED",
        score: Math.round(score),
        evidenceLevel: "MEDIUM",
        rationale:
          remainingForecast === 0
            ? "Closed revenue already meets or exceeds the reported forecast — the entire forecast is evidence-locked."
            : `Closed revenue covers ${(closedShare * 100).toFixed(1)}% of the forecast (HIGH evidence). Weighted pipeline covers ${(coverageOfRemainder * 100).toFixed(1)}% of the remaining ${remainingForecast.toLocaleString()} needed (MEDIUM evidence). The rest is unweighted judgment.`,
        evidenceUsed: [...evidenceUsed, "Weighted pipeline"],
        missingEvidence: null,
      });
    }
  }

  // 2. Historical Forecast Accuracy (weight 14) — HIGH evidence.
  {
    let accuracy: number | null = input.historicalForecastAccuracyPct;
    let source = "directly reported historical forecast accuracy";
    if (accuracy === null && input.previousForecast !== null && input.previousActual !== null && input.previousForecast > 0) {
      accuracy = clamp(100 - (Math.abs(input.previousForecast - input.previousActual) / input.previousForecast) * 100, 0, 100);
      source = `prior period forecast (${input.previousForecast.toLocaleString()}) vs. actual (${input.previousActual.toLocaleString()})`;
    }
    if (accuracy === null) {
      dims.push({
        id: "historicalAccuracy",
        name: "Historical Forecast Accuracy",
        question: "Has this forecasting process been accurate before?",
        weight: 14,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "Historical forecast accuracy is unavailable — current reliability cannot be validated against prior forecasting behavior.",
        evidenceUsed: [],
        missingEvidence: "Historical forecast accuracy percentage, or a prior-period forecast and actual pair.",
      });
    } else {
      dims.push({
        id: "historicalAccuracy",
        name: "Historical Forecast Accuracy",
        question: "Has this forecasting process been accurate before?",
        weight: 14,
        status: "SCORED",
        score: Math.round(accuracy),
        evidenceLevel: "HIGH",
        rationale: `Derived from ${source}: ${accuracy.toFixed(1)}% historical accuracy.`,
        evidenceUsed: [source],
        missingEvidence: null,
      });
    }
  }

  // 3. Commit Reliability (weight 14) — HIGH evidence, requires historical commit accuracy.
  {
    if (input.historicalCommitAccuracyPct === null) {
      dims.push({
        id: "commitReliability",
        name: "Commit Reliability",
        question: "Does this team's commit historically convert to closed revenue?",
        weight: 14,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "No historical commit accuracy on file — the current commit label cannot be validated against past commit behavior. Commit is treated as an unverified label, not evidence.",
        evidenceUsed: [],
        missingEvidence: "Historical commit accuracy percentage (share of past commit that closed as committed).",
      });
    } else {
      dims.push({
        id: "commitReliability",
        name: "Commit Reliability",
        question: "Does this team's commit historically convert to closed revenue?",
        weight: 14,
        status: "SCORED",
        score: Math.round(clamp(input.historicalCommitAccuracyPct, 0, 100)),
        evidenceLevel: "HIGH",
        rationale: `Historical commit accuracy is ${input.historicalCommitAccuracyPct.toFixed(1)}% — this is the measured share of past commit that has actually closed as committed.`,
        evidenceUsed: ["Historical commit accuracy"],
        missingEvidence: null,
      });
    }
  }

  // 4. Timing Confidence (weight 10) — structural: opportunity age vs. sales cycle,
  // and remaining runway vs. sales cycle.
  {
    const evidenceUsed: string[] = [];
    const subScores: number[] = [];
    let ageRatio: number | null = null;
    if (input.avgOpportunityAgeDays !== null && input.avgSalesCycleDays !== null && input.avgSalesCycleDays > 0) {
      ageRatio = input.avgOpportunityAgeDays / input.avgSalesCycleDays;
      const s = ageRatio <= 1 ? 100 : clamp(100 - (ageRatio - 1) * 80, 10, 100);
      subScores.push(s);
      evidenceUsed.push("Average opportunity age", "Average sales cycle");
    }
    let runwayRatio: number | null = null;
    if (input.daysRemainingInPeriod !== null && input.avgSalesCycleDays !== null && input.avgSalesCycleDays > 0) {
      runwayRatio = input.daysRemainingInPeriod / input.avgSalesCycleDays;
      const s = clamp(runwayRatio * 100, 0, 100);
      subScores.push(s);
      evidenceUsed.push("Days remaining in period", "Average sales cycle");
    }
    if (subScores.length === 0) {
      dims.push({
        id: "timingConfidence",
        name: "Timing Confidence",
        question: "Is there structural evidence the pipeline can close within the forecast window?",
        weight: 10,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "No opportunity age, sales cycle, or remaining-runway data supplied — timing cannot be assessed structurally. A close date on file is not, by itself, evidence a deal will close.",
        evidenceUsed: [],
        missingEvidence: "Average sales cycle length, average opportunity age, and/or days remaining in the forecast period.",
      });
    } else {
      const score = subScores.reduce((a, b) => a + b, 0) / subScores.length;
      const parts: string[] = [];
      if (ageRatio !== null) parts.push(`average opportunity age runs ${ageRatio.toFixed(2)}× the typical sales cycle`);
      if (runwayRatio !== null) parts.push(`remaining period runway is ${runwayRatio.toFixed(2)}× the typical sales cycle`);
      dims.push({
        id: "timingConfidence",
        name: "Timing Confidence",
        question: "Is there structural evidence the pipeline can close within the forecast window?",
        weight: 10,
        status: "SCORED",
        score: Math.round(score),
        evidenceLevel: "MEDIUM",
        rationale: `Based on measured structure: ${parts.join("; ")}.`,
        evidenceUsed: [...new Set(evidenceUsed)],
        missingEvidence: null,
      });
    }
  }

  // 5. Conversion Support (weight 12) — HIGH evidence, requires historical win rate.
  {
    if (input.historicalWinRatePct === null) {
      dims.push({
        id: "conversionSupport",
        name: "Conversion Support",
        question: "Does the historical win rate support the conversion this forecast requires?",
        weight: 12,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "No historical win rate on file — the conversion assumption embedded in this forecast cannot be checked against demonstrated performance.",
        evidenceUsed: [],
        missingEvidence: "Historical win/conversion rate from qualified pipeline to closed-won.",
      });
    } else if (input.openPipeline <= 0) {
      dims.push({
        id: "conversionSupport",
        name: "Conversion Support",
        question: "Does the historical win rate support the conversion this forecast requires?",
        weight: 12,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "Open pipeline is $0 — there is no pipeline to test the implied conversion rate against.",
        evidenceUsed: [],
        missingEvidence: "A non-zero open pipeline value.",
      });
    } else {
      const impliedConversionPct = clamp((remainingForecast / input.openPipeline) * 100, 0, 1000);
      const score = impliedConversionPct <= 0 ? 100 : clamp((input.historicalWinRatePct / impliedConversionPct) * 100, 0, 100);
      dims.push({
        id: "conversionSupport",
        name: "Conversion Support",
        question: "Does the historical win rate support the conversion this forecast requires?",
        weight: 12,
        status: "SCORED",
        score: Math.round(score),
        evidenceLevel: "HIGH",
        rationale:
          impliedConversionPct <= 0
            ? "The unclosed forecast is $0 — no further conversion from pipeline is required."
            : `This forecast requires converting ${impliedConversionPct.toFixed(1)}% of open pipeline. Historical win rate is ${input.historicalWinRatePct.toFixed(1)}%. ${
                input.historicalWinRatePct >= impliedConversionPct
                  ? "Historical performance meets or exceeds the required rate."
                  : "Historical performance falls short of the rate this forecast assumes."
              }`,
        evidenceUsed: ["Historical win rate", "Open pipeline", "Current forecast", "Closed revenue"],
        missingEvidence: null,
      });
    }
  }

  // 6. Pipeline Sufficiency (weight 10) — MEDIUM evidence, coverage-based.
  // Explicitly never treated as a stand-alone proxy for reliability — see narrative.
  {
    if (input.revenueTarget <= 0) {
      dims.push({
        id: "pipelineSufficiency",
        name: "Pipeline Sufficiency",
        question: "Is there enough open pipeline to plausibly cover the remaining target?",
        weight: 10,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "Revenue target is $0 — coverage cannot be calculated against a $0 target.",
        evidenceUsed: [],
        missingEvidence: "A non-zero revenue target.",
      });
    } else if (remainingTarget <= 0) {
      dims.push({
        id: "pipelineSufficiency",
        name: "Pipeline Sufficiency",
        question: "Is there enough open pipeline to plausibly cover the remaining target?",
        weight: 10,
        status: "SCORED",
        score: 100,
        evidenceLevel: "MEDIUM",
        rationale: "Closed revenue already meets or exceeds the target — there is no remaining gap for pipeline to cover.",
        evidenceUsed: ["Closed revenue", "Revenue target"],
        missingEvidence: null,
      });
    } else {
      const coverage = input.openPipeline / remainingTarget;
      const score = clamp((coverage / 3) * 100, 0, 100);
      dims.push({
        id: "pipelineSufficiency",
        name: "Pipeline Sufficiency",
        question: "Is there enough open pipeline to plausibly cover the remaining target?",
        weight: 10,
        status: "SCORED",
        score: Math.round(score),
        evidenceLevel: "MEDIUM",
        rationale: `Open pipeline (${input.openPipeline.toLocaleString()}) is ${coverage.toFixed(2)}× the remaining target (${remainingTarget.toLocaleString()}). Coverage alone does not establish reliability — read this alongside Conversion Support and Stage Evidence below.`,
        evidenceUsed: ["Open pipeline", "Revenue target", "Closed revenue"],
        missingEvidence: null,
      });
    }
  }

  // 7. Stage Evidence (weight 8) — MEDIUM evidence.
  {
    if (input.lateStagePipelineValue === null) {
      dims.push({
        id: "stageEvidence",
        name: "Stage Evidence",
        question: "How much of the open pipeline has progressed to a stage that reflects concrete buyer commitment?",
        weight: 8,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "Late-stage pipeline value was not supplied — stage composition of the pipeline cannot be assessed.",
        evidenceUsed: [],
        missingEvidence: "Late-stage (proposal/negotiation or later) pipeline value.",
      });
    } else if (input.openPipeline <= 0) {
      dims.push({
        id: "stageEvidence",
        name: "Stage Evidence",
        question: "How much of the open pipeline has progressed to a stage that reflects concrete buyer commitment?",
        weight: 8,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "Open pipeline is $0 — stage composition is not applicable.",
        evidenceUsed: [],
        missingEvidence: "A non-zero open pipeline value.",
      });
    } else {
      const lateShare = (input.lateStagePipelineValue / input.openPipeline) * 100;
      const score = clamp(lateShare * 1.4, 0, 100);
      dims.push({
        id: "stageEvidence",
        name: "Stage Evidence",
        question: "How much of the open pipeline has progressed to a stage that reflects concrete buyer commitment?",
        weight: 8,
        status: "SCORED",
        score: Math.round(score),
        evidenceLevel: "MEDIUM",
        rationale: `${lateShare.toFixed(1)}% of open pipeline sits in late stage. The remainder relies on earlier-stage activity evidence.`,
        evidenceUsed: ["Late-stage pipeline value", "Open pipeline"],
        missingEvidence: null,
      });
    }
  }

  // 8. Slippage Exposure (weight 8) — historical behavior: slippage rate or repeated close-date pushes.
  {
    let score: number | null = null;
    let rationale = "";
    let evidenceLevel: "HIGH" | "MEDIUM" | "N/A" = "N/A";
    const evidenceUsed: string[] = [];
    if (input.historicalSlippageRatePct !== null) {
      score = clamp(100 - input.historicalSlippageRatePct, 0, 100);
      rationale = `Historical slippage rate is ${input.historicalSlippageRatePct.toFixed(1)}% — this share of previously forecast revenue has slipped out of its forecast period.`;
      evidenceLevel = "HIGH";
      evidenceUsed.push("Historical slippage rate");
    } else if (input.closeDatePushes !== null && input.numOpenOpportunities !== null && input.numOpenOpportunities > 0) {
      const pushRatio = input.closeDatePushes / input.numOpenOpportunities;
      score = clamp(100 - pushRatio * 150, 0, 100);
      rationale = `${input.closeDatePushes} close-date pushes across ${input.numOpenOpportunities} open opportunities (${pushRatio.toFixed(2)} pushes per opportunity) — repeated pushes are the strongest available proxy for slippage risk without direct historical slippage data.`;
      evidenceLevel = "MEDIUM";
      evidenceUsed.push("Close-date pushes", "Open opportunity count");
    }
    if (score === null) {
      dims.push({
        id: "slippageExposure",
        name: "Slippage Exposure",
        question: "Do committed deals historically slip out of the period they were forecast in?",
        weight: 8,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "No historical slippage rate or close-date push data supplied — slippage behavior is unknown.",
        evidenceUsed: [],
        missingEvidence: "Historical slippage rate, or close-date push count with open opportunity count.",
      });
    } else {
      dims.push({
        id: "slippageExposure",
        name: "Slippage Exposure",
        question: "Do committed deals historically slip out of the period they were forecast in?",
        weight: 8,
        status: "SCORED",
        score: Math.round(score),
        evidenceLevel,
        rationale,
        evidenceUsed,
        missingEvidence: null,
      });
    }
  }

  // 9. Concentration Exposure (weight 6).
  {
    if (input.top1DealValue === null || input.openPipeline <= 0) {
      dims.push({
        id: "concentrationExposure",
        name: "Concentration Exposure",
        question: "How dependent is this forecast on a small number of opportunities?",
        weight: 6,
        status: "INSUFFICIENT_EVIDENCE",
        score: null,
        evidenceLevel: "N/A",
        rationale: "Top-1 deal value was not supplied, or open pipeline is $0 — concentration cannot be measured.",
        evidenceUsed: [],
        missingEvidence: "Top-1 (largest) open deal value, and optionally top-3 combined deal value.",
      });
    } else {
      const top1Share = (input.top1DealValue / input.openPipeline) * 100;
      const top1Score = clamp(100 - top1Share * 1.5, 0, 100);
      let score = top1Score;
      const evidenceUsed = ["Top-1 deal value", "Open pipeline"];
      let rationale = `The single largest open deal represents ${top1Share.toFixed(1)}% of open pipeline.`;
      if (input.top3DealsValue !== null) {
        const top3Share = (input.top3DealsValue / input.openPipeline) * 100;
        const top3Score = clamp(100 - top3Share, 0, 100);
        score = (top1Score + top3Score) / 2;
        rationale += ` The top three deals combined represent ${top3Share.toFixed(1)}% of open pipeline.`;
        evidenceUsed.push("Top-3 deal value");
      }
      dims.push({
        id: "concentrationExposure",
        name: "Concentration Exposure",
        question: "How dependent is this forecast on a small number of opportunities?",
        weight: 6,
        status: "SCORED",
        score: Math.round(score),
        evidenceLevel: "MEDIUM",
        rationale,
        evidenceUsed,
        missingEvidence: null,
      });
    }
  }

  // 10. Forecast Discipline (weight 6) — always computable from core inputs and
  // the structural integrity findings above.
  {
    let score = 100;
    const applied: string[] = [];
    const penalties: Record<string, number> = {
      "commit-gt-forecast": 30,
      "bestcase-lt-commit": 25,
      "forecast-gt-bestcase": 15,
      "forecast-lt-closed": 40,
      "zero-pipeline-with-gap": 20,
    };
    for (const issue of issues) {
      if (penalties[issue.id] !== undefined) {
        score -= penalties[issue.id];
        applied.push(issue.field);
      }
    }
    score = clamp(score, 0, 100);
    dims.push({
      id: "forecastDiscipline",
      name: "Forecast Discipline",
      question: "Are the reported forecast figures internally consistent with each other?",
      weight: 6,
      status: "SCORED",
      score: Math.round(score),
      evidenceLevel: "MEDIUM",
      rationale:
        applied.length === 0
          ? "Commit, best case, current forecast, and closed revenue are all internally consistent with each other."
          : `Internal inconsistencies detected in: ${applied.join(", ")}.`,
      evidenceUsed: ["Commit", "Best case", "Current forecast", "Closed revenue", "Open pipeline", "Revenue target"],
      missingEvidence: null,
    });
  }

  return dims;
}
