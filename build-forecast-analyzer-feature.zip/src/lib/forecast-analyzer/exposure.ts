import type {
  ForecastAnalyzerInput,
  RevenueExposureTier,
  ConcentrationAnalysis,
  TimingRiskProfile,
  ScenarioCase,
  CoverageSummary,
  EvidenceConfidence,
} from "./types";
import { clamp } from "./format";

export function computeRevenueExposure(input: ForecastAnalyzerInput): {
  tiers: RevenueExposureTier[];
  remainingTargetGap: number;
} {
  const tiers: RevenueExposureTier[] = [];
  const closed = input.closedRevenue;

  tiers.push({
    id: "closedLocked",
    label: "Closed / Evidence-Locked",
    amount: closed,
    evidenceLevel: "HIGH",
    formula: "Closed revenue, as reported.",
    interpretation: "Revenue with no forward dependency — already booked.",
  });

  if (input.historicalCommitAccuracyPct !== null) {
    const validatedCommit = input.commit * (input.historicalCommitAccuracyPct / 100);
    tiers.push({
      id: "commitValidated",
      label: "Commit, Historically Validated",
      amount: validatedCommit,
      evidenceLevel: "HIGH",
      formula: `Commit (${input.commit.toLocaleString()}) × historical commit accuracy (${input.historicalCommitAccuracyPct.toFixed(1)}%)`,
      interpretation: "Expected commit conversion based on this team's demonstrated commit-to-close history, not the commit label itself.",
    });
  } else {
    tiers.push({
      id: "commitUnvalidated",
      label: "Commit, Unvalidated",
      amount: input.commit,
      evidenceLevel: "LOW",
      formula: "Commit at face value — no historical commit accuracy on file to discount it.",
      interpretation: "This amount reflects a rep-reported label, not measured evidence. Treat as directional only.",
    });
  }

  const pipelineDependent = Math.max(input.currentForecast - closed - input.commit, 0);
  if (pipelineDependent > 0) {
    tiers.push({
      id: "pipelineDependent",
      label: "Pipeline-Conversion-Dependent",
      amount: pipelineDependent,
      evidenceLevel: input.historicalWinRatePct !== null ? "MEDIUM" : "LOW",
      formula: "Current forecast − closed revenue − commit.",
      interpretation:
        input.historicalWinRatePct !== null
          ? "Beyond commit, the forecast depends on additional pipeline conversion. Cross-check against Conversion Support."
          : "Beyond commit, the forecast depends on additional pipeline conversion with no historical win rate to validate the assumption.",
    });
  }

  let timingExposed: number | null = null;
  let timingFormula = "Insufficient timing data to isolate a timing-exposed amount.";
  const atRiskBase = input.commit + pipelineDependent;
  if (input.closeDatePushes !== null && input.numOpenOpportunities !== null && input.numOpenOpportunities > 0) {
    const pushRatio = clamp(input.closeDatePushes / input.numOpenOpportunities, 0, 1);
    timingExposed = atRiskBase * pushRatio;
    timingFormula = `(Commit + pipeline-dependent forecast) × close-date push ratio (${(pushRatio * 100).toFixed(1)}%).`;
  } else if (input.avgOpportunityAgeDays !== null && input.avgSalesCycleDays !== null && input.avgSalesCycleDays > 0) {
    const ageRatio = input.avgOpportunityAgeDays / input.avgSalesCycleDays;
    if (ageRatio > 1) {
      const factor = clamp(ageRatio - 1, 0, 1);
      timingExposed = atRiskBase * factor;
      timingFormula = `(Commit + pipeline-dependent forecast) × (opportunity-age-to-cycle overrun of ${((ageRatio - 1) * 100).toFixed(1)}%).`;
    }
  }
  tiers.push({
    id: "timingExposed",
    label: "Timing-Exposed",
    amount: timingExposed,
    evidenceLevel: timingExposed !== null ? "MEDIUM" : "N/A",
    formula: timingFormula,
    interpretation:
      timingExposed !== null
        ? "The portion of unclosed forecast most likely to slip past this forecast period based on push history or opportunity age."
        : "Supply close-date push counts or opportunity age vs. sales cycle to quantify timing exposure.",
  });

  const concentrationExposed = input.top1DealValue;
  tiers.push({
    id: "concentrationExposed",
    label: "Concentration-Exposed",
    amount: concentrationExposed,
    evidenceLevel: concentrationExposed !== null ? "MEDIUM" : "N/A",
    formula: concentrationExposed !== null ? "Value of the single largest open opportunity." : "Top-1 deal value not supplied.",
    interpretation:
      concentrationExposed !== null
        ? "Revenue that disappears from the forecast in full if this one opportunity does not close."
        : "Supply the largest open deal value to quantify single-deal exposure.",
  });

  const remainingTargetGap = Math.max(input.revenueTarget - input.currentForecast, 0);
  tiers.push({
    id: "remainingGap",
    label: "Remaining Target Gap (Unforecasted)",
    amount: remainingTargetGap,
    evidenceLevel: "N/A",
    formula: "Revenue target − current forecast (floored at $0).",
    interpretation:
      remainingTargetGap > 0
        ? "White space with no forecast coverage at all — not even speculative pipeline. Requires net-new pipeline generation, not forecast confidence work."
        : "The reported forecast already covers the full target.",
  });

  return { tiers, remainingTargetGap };
}

export function computeCoverage(input: ForecastAnalyzerInput): CoverageSummary {
  const remainingTarget = Math.max(input.revenueTarget - input.closedRevenue, 0);
  if (input.revenueTarget <= 0) {
    return { ratio: null, remainingTarget, note: "Revenue target is $0 — coverage is not meaningful." };
  }
  if (remainingTarget <= 0) {
    return { ratio: null, remainingTarget, note: "Target already met from closed revenue — coverage is not applicable." };
  }
  const ratio = input.openPipeline / remainingTarget;
  return {
    ratio,
    remainingTarget,
    note: `Open pipeline is ${ratio.toFixed(2)}× the remaining target. Coverage describes volume, not quality — it does not by itself indicate a reliable forecast.`,
  };
}

export function computeConcentration(input: ForecastAnalyzerInput): ConcentrationAnalysis {
  if (input.top1DealValue === null || input.openPipeline <= 0) {
    return {
      top1SharePipeline: null,
      top3SharePipeline: null,
      top1ShareForecast: null,
      commitAvgDealSize: input.dealsInCommit && input.dealsInCommit > 0 ? input.commit / input.dealsInCommit : null,
      narrative: "Top-1 deal value was not supplied, so concentration cannot be quantified.",
      riskLevel: "UNKNOWN",
    };
  }
  const top1SharePipeline = (input.top1DealValue / input.openPipeline) * 100;
  const top3SharePipeline = input.top3DealsValue !== null ? (input.top3DealsValue / input.openPipeline) * 100 : null;
  const top1ShareForecast = input.currentForecast > 0 ? (input.top1DealValue / input.currentForecast) * 100 : null;
  const commitAvgDealSize = input.dealsInCommit && input.dealsInCommit > 0 ? input.commit / input.dealsInCommit : null;

  let riskLevel: ConcentrationAnalysis["riskLevel"] = "LOW";
  if (top1SharePipeline >= 45) riskLevel = "SEVERE";
  else if (top1SharePipeline >= 25) riskLevel = "HIGH";
  else if (top1SharePipeline >= 10) riskLevel = "MODERATE";

  const parts: string[] = [
    `The single largest open opportunity is ${top1SharePipeline.toFixed(1)}% of open pipeline${
      top1ShareForecast !== null ? ` and ${top1ShareForecast.toFixed(1)}% of the current forecast` : ""
    }.`,
  ];
  if (top3SharePipeline !== null) {
    parts.push(`The top three opportunities combined are ${top3SharePipeline.toFixed(1)}% of open pipeline.`);
  }
  if (commitAvgDealSize !== null && input.dealsInCommit) {
    parts.push(`Commit spans ${input.dealsInCommit} deal(s) averaging ${commitAvgDealSize.toLocaleString()} each.`);
    if (input.dealsInCommit <= 2) {
      parts.push("Commit rests on very few opportunities — any single slip has an outsized effect on the reported number.");
    }
  }

  return {
    top1SharePipeline,
    top3SharePipeline,
    top1ShareForecast,
    commitAvgDealSize,
    narrative: parts.join(" "),
    riskLevel,
  };
}

export function computeTimingRisk(input: ForecastAnalyzerInput): TimingRiskProfile {
  let ageToCycleRatio: number | null = null;
  let pushRatio: number | null = null;
  let runwayVsCycle: number | null = null;

  if (input.avgOpportunityAgeDays !== null && input.avgSalesCycleDays !== null && input.avgSalesCycleDays > 0) {
    ageToCycleRatio = input.avgOpportunityAgeDays / input.avgSalesCycleDays;
  }
  if (input.closeDatePushes !== null && input.numOpenOpportunities !== null && input.numOpenOpportunities > 0) {
    pushRatio = input.closeDatePushes / input.numOpenOpportunities;
  }
  if (input.daysRemainingInPeriod !== null && input.avgSalesCycleDays !== null && input.avgSalesCycleDays > 0) {
    runwayVsCycle = input.daysRemainingInPeriod / input.avgSalesCycleDays;
  }

  if (ageToCycleRatio === null && pushRatio === null && runwayVsCycle === null) {
    return {
      ageToCycleRatio: null,
      pushRatio: null,
      runwayVsCycle: null,
      narrative: "No opportunity age, sales cycle, push, or runway data supplied — timing risk is unknown, not low.",
      riskLevel: "UNKNOWN",
    };
  }

  const signals: number[] = [];
  const parts: string[] = [];
  if (ageToCycleRatio !== null) {
    signals.push(ageToCycleRatio > 1 ? clamp((ageToCycleRatio - 1) * 2, 0, 3) : 0);
    parts.push(
      ageToCycleRatio > 1
        ? `Average opportunity age is ${ageToCycleRatio.toFixed(2)}× the typical sales cycle — pipeline is aging past the point where it normally closes.`
        : `Average opportunity age is within the typical sales cycle (${ageToCycleRatio.toFixed(2)}×).`,
    );
  }
  if (pushRatio !== null) {
    signals.push(clamp(pushRatio * 3, 0, 3));
    parts.push(`${(pushRatio * 100).toFixed(0)}% of open opportunities (as a ratio of pushes to opportunities) have had a close date pushed.`);
  }
  if (runwayVsCycle !== null) {
    signals.push(runwayVsCycle < 1 ? clamp((1 - runwayVsCycle) * 3, 0, 3) : 0);
    parts.push(
      runwayVsCycle < 1
        ? `Only ${runwayVsCycle.toFixed(2)}× a full sales cycle remains in the period — new pipeline generated now is unlikely to close within the remaining window.`
        : `Remaining period runway (${runwayVsCycle.toFixed(2)}× a sales cycle) is sufficient for a fresh opportunity to complete a full cycle.`,
    );
  }

  const severity = signals.reduce((a, b) => a + b, 0) / signals.length;
  let riskLevel: TimingRiskProfile["riskLevel"] = "LOW";
  if (severity >= 2) riskLevel = "SEVERE";
  else if (severity >= 1.2) riskLevel = "HIGH";
  else if (severity >= 0.4) riskLevel = "MODERATE";

  return { ageToCycleRatio, pushRatio, runwayVsCycle, narrative: parts.join(" "), riskLevel };
}

export function computeScenarios(
  input: ForecastAnalyzerInput,
  evidenceConfidence: EvidenceConfidence,
): { scenarios: ScenarioCase[] | null; note: string | null } {
  const closed = input.closedRevenue;
  const conservativeAssumptions: string[] = ["Includes closed revenue."];
  let conservative: number;
  if (input.historicalCommitAccuracyPct !== null) {
    conservative = closed + input.commit * (input.historicalCommitAccuracyPct / 100);
    conservativeAssumptions.push(
      `Commit discounted to its historical accuracy rate (${input.historicalCommitAccuracyPct.toFixed(1)}%) rather than taken at face value.`,
    );
  } else {
    conservative = closed;
    conservativeAssumptions.push("Commit excluded — no historical commit accuracy is on file to validate it, so it is not counted as evidence-backed.");
  }

  const base = input.currentForecast;
  const baseAssumptions = ["Equal to the forecast currently being reported, taken at face value with no adjustment."];

  let upside: number | null = null;
  const upsideAssumptions: string[] = [];
  if (input.bestCase !== null) {
    upside = Math.max(input.bestCase, input.currentForecast);
    upsideAssumptions.push("Equal to the reported best case (or the current forecast if higher).");
  } else {
    upsideAssumptions.push("Not reported — no best-case figure was supplied.");
  }

  const scenarios: ScenarioCase[] = [
    { id: "conservative", label: "Conservative", amount: conservative, assumptions: conservativeAssumptions, confidence: evidenceConfidence },
    { id: "base", label: "Base", amount: base, assumptions: baseAssumptions, confidence: evidenceConfidence },
    { id: "upside", label: "Upside", amount: upside, assumptions: upsideAssumptions, confidence: evidenceConfidence },
  ];

  const note =
    evidenceConfidence === "LIMITED"
      ? "Evidence Confidence is Limited — treat the spread between these cases as wide and unreliable, not as a forecast range to plan against."
      : evidenceConfidence === "MODERATE"
      ? "Evidence Confidence is Moderate — these cases are analytical bounds, not predictions of what will close."
      : "Evidence Confidence is High — these cases are still analytical bounds, not predictions, but rest on more measured evidence than a typical forecast review.";

  return { scenarios, note };
}
