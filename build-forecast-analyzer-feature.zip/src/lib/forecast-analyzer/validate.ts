import type { ForecastAnalyzerInput, IntegrityIssue } from "./types";

const pct = (n: number) => `${n.toFixed(1)}%`;
const money = (n: number) => `$${n.toLocaleString("en-US", { maximumFractionDigits: 0 })}`;

/**
 * Detects contradictory or out-of-range business data.
 * Never repairs the data — only reports what is wrong and what conclusion
 * it limits. BLOCKING issues withhold the Forecast Reliability Score.
 * WARNING issues still lower the Forecast Discipline dimension and are
 * surfaced in the failure map.
 */
export function validateForecastInput(input: ForecastAnalyzerInput): IntegrityIssue[] {
  const issues: IntegrityIssue[] = [];

  const nonNegative: Array<[keyof ForecastAnalyzerInput, string]> = [
    ["revenueTarget", "Revenue target"],
    ["closedRevenue", "Closed revenue"],
    ["currentForecast", "Current forecast"],
    ["commit", "Commit"],
    ["openPipeline", "Open pipeline"],
    ["bestCase", "Best case"],
    ["weightedPipeline", "Weighted pipeline"],
    ["top1DealValue", "Top-1 deal value"],
    ["top3DealsValue", "Top-3 deal value"],
    ["lateStagePipelineValue", "Late-stage pipeline value"],
    ["previousForecast", "Previous forecast"],
    ["previousActual", "Previous actual"],
  ];
  for (const [key, label] of nonNegative) {
    const value = input[key];
    if (typeof value === "number" && value < 0) {
      issues.push({
        id: `negative:${key}`,
        field: label,
        severity: "BLOCKING",
        message: `${label} is negative (${money(value)}).`,
        limits: "Revenue figures cannot be negative. Reliability scoring is withheld until this is corrected.",
      });
    }
  }

  const pctFields: Array<[keyof ForecastAnalyzerInput, string]> = [
    ["historicalForecastAccuracyPct", "Historical forecast accuracy"],
    ["historicalWinRatePct", "Historical win rate"],
    ["historicalCommitAccuracyPct", "Historical commit accuracy"],
    ["historicalSlippageRatePct", "Historical slippage rate"],
  ];
  for (const [key, label] of pctFields) {
    const value = input[key];
    if (typeof value === "number" && (value < 0 || value > 100)) {
      issues.push({
        id: `pctrange:${key}`,
        field: label,
        severity: "BLOCKING",
        message: `${label} of ${pct(value)} is outside the valid 0–100% range.`,
        limits: "The dimension relying on this figure cannot be scored until the value is corrected.",
      });
    }
  }

  if (input.commit > input.currentForecast) {
    issues.push({
      id: "commit-gt-forecast",
      field: "Commit vs. current forecast",
      severity: "WARNING",
      message: `Commit (${money(input.commit)}) exceeds the reported forecast (${money(input.currentForecast)}).`,
      limits: "The forecast being reported upward understates what the team has already committed to. Forecast Discipline is reduced.",
    });
  }

  if (input.bestCase !== null && input.bestCase < input.commit) {
    issues.push({
      id: "bestcase-lt-commit",
      field: "Best case vs. commit",
      severity: "WARNING",
      message: `Best case (${money(input.bestCase)}) is lower than commit (${money(input.commit)}).`,
      limits: "Best case should represent the upside ceiling above commit. This scenario relationship is internally inconsistent, so upside scenario framing is unreliable.",
    });
  }

  if (input.bestCase !== null && input.currentForecast > input.bestCase) {
    issues.push({
      id: "forecast-gt-bestcase",
      field: "Current forecast vs. best case",
      severity: "WARNING",
      message: `Current forecast (${money(input.currentForecast)}) exceeds the stated best case (${money(input.bestCase)}).`,
      limits: "The reported forecast is above the upside ceiling supplied. Scenario bounds cannot be trusted as reported.",
    });
  }

  if (input.currentForecast < input.closedRevenue) {
    issues.push({
      id: "forecast-lt-closed",
      field: "Current forecast vs. closed revenue",
      severity: "WARNING",
      message: `Current forecast (${money(input.currentForecast)}) is lower than closed revenue already booked (${money(input.closedRevenue)}).`,
      limits: "A forecast cannot be lower than revenue already closed in the period. Evidence Strength and Forecast Discipline are both degraded.",
    });
  }

  if (input.revenueTarget === 0) {
    issues.push({
      id: "zero-target",
      field: "Revenue target",
      severity: "WARNING",
      message: "Revenue target is $0.",
      limits: "Pipeline Sufficiency and coverage cannot be meaningfully calculated against a $0 target.",
    });
  }

  const remainingTarget = input.revenueTarget - input.closedRevenue;
  if (input.revenueTarget > 0 && remainingTarget <= 0) {
    issues.push({
      id: "target-met",
      field: "Remaining target",
      severity: "WARNING",
      message: `Closed revenue (${money(input.closedRevenue)}) already meets or exceeds the target (${money(input.revenueTarget)}).`,
      limits: "Pipeline Sufficiency is not applicable — the remaining gap to close is zero or negative.",
    });
  }

  if (input.openPipeline === 0 && remainingTarget > 0) {
    issues.push({
      id: "zero-pipeline-with-gap",
      field: "Open pipeline",
      severity: "WARNING",
      message: `Open pipeline is $0 while ${money(remainingTarget)} of target remains uncovered.`,
      limits: "There is no open pipeline evidence to support closing the remaining target. This is a material exposure, not a data error.",
    });
  }

  if (
    input.numOpenOpportunities !== null &&
    input.numOpenOpportunities === 0 &&
    input.openPipeline > 0
  ) {
    issues.push({
      id: "opps-zero-pipeline-positive",
      field: "Open opportunity count vs. open pipeline",
      severity: "BLOCKING",
      message: `Open pipeline is ${money(input.openPipeline)} but the open opportunity count is 0.`,
      limits: "Pipeline value cannot exist with zero opportunities. Stage, concentration, and timing analysis are withheld until this is corrected.",
    });
  }

  if (
    input.numOpenOpportunities !== null &&
    input.numOpenOpportunities > 0 &&
    input.openPipeline === 0
  ) {
    issues.push({
      id: "opps-positive-pipeline-zero",
      field: "Open opportunity count vs. open pipeline",
      severity: "BLOCKING",
      message: `${input.numOpenOpportunities} open opportunities were reported with $0 of open pipeline value.`,
      limits: "Opportunity count without pipeline value is internally inconsistent. Stage, concentration, and timing analysis are withheld until this is corrected.",
    });
  }

  if (input.top1DealValue !== null && input.top1DealValue > input.openPipeline) {
    issues.push({
      id: "top1-gt-pipeline",
      field: "Top-1 deal value vs. open pipeline",
      severity: "BLOCKING",
      message: `Top-1 deal value (${money(input.top1DealValue)}) exceeds total open pipeline (${money(input.openPipeline)}).`,
      limits: "A single deal cannot exceed total pipeline. Concentration analysis is withheld until this is corrected.",
    });
  }

  if (input.top3DealsValue !== null && input.top3DealsValue > input.openPipeline) {
    issues.push({
      id: "top3-gt-pipeline",
      field: "Top-3 deal value vs. open pipeline",
      severity: "BLOCKING",
      message: `Top-3 combined deal value (${money(input.top3DealsValue)}) exceeds total open pipeline (${money(input.openPipeline)}).`,
      limits: "Combined top deals cannot exceed total pipeline. Concentration analysis is withheld until this is corrected.",
    });
  }

  if (
    input.top1DealValue !== null &&
    input.top3DealsValue !== null &&
    input.top3DealsValue < input.top1DealValue
  ) {
    issues.push({
      id: "top3-lt-top1",
      field: "Top-3 deal value vs. top-1 deal value",
      severity: "BLOCKING",
      message: `Top-3 combined value (${money(input.top3DealsValue)}) is lower than the top-1 deal alone (${money(input.top1DealValue)}).`,
      limits: "The top-3 figure must include the top-1 deal. Concentration analysis is withheld until this is corrected.",
    });
  }

  if (input.weightedPipeline !== null && input.weightedPipeline > input.openPipeline) {
    issues.push({
      id: "weighted-gt-open",
      field: "Weighted pipeline vs. open pipeline",
      severity: "BLOCKING",
      message: `Weighted pipeline (${money(input.weightedPipeline)}) exceeds unweighted open pipeline (${money(input.openPipeline)}).`,
      limits: "Weighted value cannot exceed raw pipeline value. Evidence Strength is withheld until this is corrected.",
    });
  }

  if (
    input.lateStagePipelineValue !== null &&
    input.lateStagePipelineValue > input.openPipeline
  ) {
    issues.push({
      id: "latestage-gt-open",
      field: "Late-stage pipeline value vs. open pipeline",
      severity: "BLOCKING",
      message: `Late-stage pipeline (${money(input.lateStagePipelineValue)}) exceeds total open pipeline (${money(input.openPipeline)}).`,
      limits: "Late-stage value is a subset of total pipeline. Stage Evidence is withheld until this is corrected.",
    });
  }

  if (
    input.dealsInCommit !== null &&
    input.numOpenOpportunities !== null &&
    input.dealsInCommit > input.numOpenOpportunities
  ) {
    issues.push({
      id: "commit-deals-gt-opps",
      field: "Deals in commit vs. open opportunity count",
      severity: "BLOCKING",
      message: `${input.dealsInCommit} deals reported in commit, more than the ${input.numOpenOpportunities} total open opportunities.`,
      limits: "Commit deals are a subset of open opportunities. Concentration and commit analysis are withheld until this is corrected.",
    });
  }

  return issues;
}
