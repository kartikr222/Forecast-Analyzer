// Forecast Analyzer™ — core type definitions.
// All monetary values are plain numbers in the reporting currency the user
// entered them in. `null` always means "unknown", never "zero".

export interface ForecastAnalyzerInput {
  forecastPeriodLabel: string;

  // Core (required) inputs
  revenueTarget: number;
  closedRevenue: number;
  currentForecast: number;
  commit: number;
  openPipeline: number;

  // Core (optional) inputs
  bestCase: number | null;
  weightedPipeline: number | null;

  // Historical evidence (optional, strengthens the diagnosis)
  previousForecast: number | null;
  previousActual: number | null;
  historicalForecastAccuracyPct: number | null;
  historicalWinRatePct: number | null;
  historicalCommitAccuracyPct: number | null;
  historicalSlippageRatePct: number | null;

  // Timing evidence (optional)
  avgSalesCycleDays: number | null;
  avgOpportunityAgeDays: number | null;
  daysRemainingInPeriod: number | null;
  closeDatePushes: number | null;

  // Structure evidence (optional)
  numOpenOpportunities: number | null;
  dealsInCommit: number | null;
  top1DealValue: number | null;
  top3DealsValue: number | null;
  lateStagePipelineValue: number | null;
}

export type EvidenceLevel = "HIGH" | "MEDIUM" | "LOW" | "N/A";
export type EvidenceConfidence = "HIGH" | "MODERATE" | "LIMITED";
export type IssueSeverity = "BLOCKING" | "WARNING";
export type FindingSeverity = "CRITICAL" | "HIGH" | "MODERATE";

export interface IntegrityIssue {
  id: string;
  field: string;
  severity: IssueSeverity;
  message: string;
  limits: string;
}

export interface DimensionResult {
  id: string;
  name: string;
  question: string;
  weight: number;
  status: "SCORED" | "INSUFFICIENT_EVIDENCE";
  score: number | null;
  evidenceLevel: EvidenceLevel;
  rationale: string;
  evidenceUsed: string[];
  missingEvidence: string | null;
}

export interface RevenueExposureTier {
  id: string;
  label: string;
  amount: number | null;
  evidenceLevel: EvidenceLevel;
  formula: string;
  interpretation: string;
}

export interface ConcentrationAnalysis {
  top1SharePipeline: number | null;
  top3SharePipeline: number | null;
  top1ShareForecast: number | null;
  commitAvgDealSize: number | null;
  narrative: string;
  riskLevel: "UNKNOWN" | "LOW" | "MODERATE" | "HIGH" | "SEVERE";
}

export interface TimingRiskProfile {
  ageToCycleRatio: number | null;
  pushRatio: number | null;
  runwayVsCycle: number | null;
  narrative: string;
  riskLevel: "UNKNOWN" | "LOW" | "MODERATE" | "HIGH" | "SEVERE";
}

export interface ScenarioCase {
  id: "conservative" | "base" | "upside";
  label: string;
  amount: number | null;
  assumptions: string[];
  confidence: EvidenceConfidence;
}

export interface FailureMapFinding {
  id: string;
  severity: FindingSeverity;
  signal: string;
  evidence: string;
  logic: string;
  commercialImplication: string;
  revenueExposure: string;
  nextInspection: string;
}

export interface MissingDataItem {
  field: string;
  why: string;
  limits: string;
  wouldImprove: string;
}

export interface ActionItem {
  id: string;
  text: string;
  relatedFindingId: string;
}

export interface ActionPlan {
  now: ActionItem[];
  next7Days: ActionItem[];
  nextCycle: ActionItem[];
  systemic: ActionItem[];
}

export interface CoverageSummary {
  ratio: number | null;
  remainingTarget: number;
  note: string;
}

export interface ExecutiveSummary {
  currentForecast: number;
  evidenceSupportedAmount: number;
  evidenceSupportedShare: number | null;
  commitReliabilityLabel: string;
  largestFragility: string;
  revenueExposedAmount: number | null;
  riskiestAssumption: string;
  firstInspection: string;
}

export interface ForecastAnalyzerResult {
  generatedAt: string;
  input: ForecastAnalyzerInput;
  integrityIssues: IntegrityIssue[];
  blocked: boolean;
  dimensions: DimensionResult[];
  reliabilityScore: number | null;
  reliabilityBand: string | null;
  evidenceConfidence: EvidenceConfidence;
  evidenceConfidenceRationale: string;
  scoredWeight: number;
  revenueExposure: RevenueExposureTier[];
  coverage: CoverageSummary;
  concentration: ConcentrationAnalysis;
  timing: TimingRiskProfile;
  scenarios: ScenarioCase[] | null;
  scenarioNote: string | null;
  failureMap: FailureMapFinding[];
  missingData: MissingDataItem[];
  actionPlan: ActionPlan;
  executiveSummary: ExecutiveSummary;
}
