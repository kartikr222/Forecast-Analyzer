import type {
  ForecastAnalyzerInput,
  DimensionResult,
  ConcentrationAnalysis,
  TimingRiskProfile,
  CoverageSummary,
  FailureMapFinding,
  MissingDataItem,
  ActionPlan,
  ActionItem,
  IntegrityIssue,
} from "./types";
import { formatMoney, formatPct } from "./format";

function dim(dims: DimensionResult[], id: string): DimensionResult | undefined {
  return dims.find((d) => d.id === id);
}

export function buildFailureMap(
  input: ForecastAnalyzerInput,
  dims: DimensionResult[],
  concentration: ConcentrationAnalysis,
  timing: TimingRiskProfile,
  coverage: CoverageSummary,
  remainingTargetGap: number,
  issues: IntegrityIssue[],
): FailureMapFinding[] {
  const findings: FailureMapFinding[] = [];

  const commitReliability = dim(dims, "commitReliability");
  if (commitReliability?.status === "SCORED" && commitReliability.score !== null && commitReliability.score < 70 && input.historicalCommitAccuracyPct !== null) {
    const shortfall = input.commit * (1 - input.historicalCommitAccuracyPct / 100);
    findings.push({
      id: "commit-underdelivers",
      severity: commitReliability.score < 50 ? "CRITICAL" : "HIGH",
      signal: "Commit has historically overstated what actually closes.",
      evidence: `Historical commit accuracy is ${formatPct(input.historicalCommitAccuracyPct)}.`,
      logic: `If the current commit of ${formatMoney(input.commit)} converts at the same historical rate, roughly ${formatMoney(shortfall)} of the committed amount will not materialize.`,
      commercialImplication: "The number leadership treats as 'safe' carries a demonstrated history of falling short.",
      revenueExposure: formatMoney(shortfall),
      nextInspection: "Pull the list of deals in commit and check each against the specific disqualifiers that caused past commit misses (single-threaded, no signed paper in flight, pushed once already).",
    });
  }

  const conversionSupport = dim(dims, "conversionSupport");
  if (conversionSupport?.status === "SCORED" && conversionSupport.score !== null && conversionSupport.score < 70) {
    findings.push({
      id: "conversion-below-history",
      severity: conversionSupport.score < 40 ? "CRITICAL" : "HIGH",
      signal: "The forecast assumes a pipeline conversion rate above what this team has historically delivered.",
      evidence: `Historical win rate is ${formatPct(input.historicalWinRatePct)}.`,
      logic: "The unclosed portion of the forecast divided by open pipeline exceeds the historical win rate — the plan requires better-than-historical performance to hold.",
      commercialImplication: "Hitting the number requires the team to outperform its own track record, with no stated reason why this period is different.",
      revenueExposure: "Portion of the forecast beyond commit — see Revenue Exposure breakdown.",
      nextInspection: "Identify what would need to change structurally (new segment, new offer, new rep ramp) to justify converting above the historical rate this period.",
    });
  }

  if (concentration.riskLevel === "HIGH" || concentration.riskLevel === "SEVERE") {
    findings.push({
      id: "concentration-risk",
      severity: concentration.riskLevel === "SEVERE" ? "CRITICAL" : "HIGH",
      signal: "The forecast is concentrated in a small number of opportunities.",
      evidence: `Top-1 deal is ${formatPct(concentration.top1SharePipeline)} of open pipeline${
        concentration.top1ShareForecast !== null ? ` and ${formatPct(concentration.top1ShareForecast)} of the current forecast` : ""
      }.`,
      logic: "A forecast that depends heavily on one or two opportunities inherits all of that opportunity's individual risk — legal review, budget approval, champion turnover.",
      commercialImplication: "A single stalled deal can move the reported number materially, independent of overall pipeline health.",
      revenueExposure: input.top1DealValue !== null ? formatMoney(input.top1DealValue) : "Not quantifiable from current inputs.",
      nextInspection: "Get a named, dated confirmation step (signed order form, procurement milestone) for the top-1 and top-3 deals this week.",
    });
  }

  if (timing.riskLevel === "HIGH" || timing.riskLevel === "SEVERE") {
    findings.push({
      id: "timing-risk",
      severity: timing.riskLevel === "SEVERE" ? "CRITICAL" : "HIGH",
      signal: "Timing evidence does not support closing within the forecast window.",
      evidence: timing.narrative,
      logic: "Opportunity age, close-date push frequency, or remaining period runway indicate the pipeline is behind the pace needed to close within this period.",
      commercialImplication: "Revenue currently forecast for this period is more likely to land in a future period, which understates next period's true starting position.",
      revenueExposure: "See Timing-Exposed tier in Revenue Exposure.",
      nextInspection: "Re-verify close dates on every opportunity older than the average sales cycle, deal by deal, this week.",
    });
  }

  if (coverage.ratio !== null && coverage.ratio < 1.5) {
    findings.push({
      id: "thin-coverage",
      severity: coverage.ratio < 1 ? "CRITICAL" : "HIGH",
      signal: "Open pipeline is thin relative to the remaining target.",
      evidence: `Open pipeline covers the remaining target at ${coverage.ratio.toFixed(2)}×.`,
      logic: "Even at a strong conversion rate, there is not enough open pipeline volume to plausibly close the remaining gap.",
      commercialImplication: "The remaining target depends on pipeline that does not yet exist being created and closed within the period.",
      revenueExposure: formatMoney(coverage.remainingTarget),
      nextInspection: "Confirm the net-new pipeline generation plan for the remainder of the period and its realistic close-by date.",
    });
  } else if (coverage.ratio !== null && coverage.ratio >= 3) {
    const stageEvidence = dim(dims, "stageEvidence");
    const weakConversion = conversionSupport?.status === "SCORED" && (conversionSupport.score ?? 0) < 70;
    const weakStage = stageEvidence?.status === "SCORED" && (stageEvidence.score ?? 0) < 50;
    if (weakConversion || weakStage) {
      findings.push({
        id: "coverage-masks-weak-evidence",
        severity: "HIGH",
        signal: "High pipeline coverage is masking weaker underlying evidence.",
        evidence: `Coverage is ${coverage.ratio.toFixed(2)}×, which looks healthy in isolation, while ${
          weakConversion ? "conversion support" : ""
        }${weakConversion && weakStage ? " and " : ""}${weakStage ? "stage evidence" : ""} score${weakConversion && weakStage ? "" : "s"} below a defensible threshold.`,
        logic: "Coverage measures volume, not quality. A large multiple of low-quality or early-stage pipeline does not convert like a smaller multiple of well-qualified, late-stage pipeline.",
        commercialImplication: "A coverage ratio presented on its own to leadership would overstate how defensible this forecast actually is.",
        revenueExposure: "See Pipeline-Conversion-Dependent tier in Revenue Exposure.",
        nextInspection: "Re-qualify the pipeline behind the coverage ratio stage by stage before reporting coverage as a reliability signal.",
      });
    }
  }

  const evidenceStrength = dim(dims, "evidenceStrength");
  if (evidenceStrength?.status === "SCORED" && evidenceStrength.score !== null && evidenceStrength.score < 50) {
    findings.push({
      id: "low-evidence-strength",
      severity: evidenceStrength.score < 30 ? "CRITICAL" : "HIGH",
      signal: "Most of the forecast is not backed by closed revenue or weighted pipeline.",
      evidence: evidenceStrength.rationale,
      logic: "A forecast built mostly on unweighted judgment beyond what closed revenue and weighted pipeline can support is fragile by construction.",
      commercialImplication: "The reported number relies on the accuracy of subjective judgment more than on measured pipeline behavior.",
      revenueExposure: "See Pipeline-Conversion-Dependent tier in Revenue Exposure.",
      nextInspection: "Require stage-weighted pipeline reporting for every opportunity contributing to forecast beyond commit.",
    });
  }

  const forecastDiscipline = dim(dims, "forecastDiscipline");
  if (forecastDiscipline?.status === "SCORED" && forecastDiscipline.score !== null && forecastDiscipline.score < 100) {
    const warningIssues = issues.filter((i) => i.severity === "WARNING");
    findings.push({
      id: "forecast-discipline-break",
      severity: forecastDiscipline.score < 60 ? "CRITICAL" : "MODERATE",
      signal: "The reported forecast figures are not internally consistent.",
      evidence: warningIssues.map((i) => i.message).join(" "),
      logic: "Commit, best case, current forecast, and closed revenue should form a consistent hierarchy. One or more of those relationships is broken.",
      commercialImplication: "Leadership cannot compare this period's numbers at face value until the reporting inconsistency is resolved.",
      revenueExposure: "Not quantifiable until the reporting inconsistency is resolved.",
      nextInspection: "Reconcile commit, best case, current forecast, and closed revenue with the source CRM report before this is presented further.",
    });
  }

  if (remainingTargetGap > 0) {
    findings.push({
      id: "unforecasted-whitespace",
      severity: remainingTargetGap > input.revenueTarget * 0.25 ? "CRITICAL" : "MODERATE",
      signal: "Part of the target has no forecast coverage at all.",
      evidence: `Revenue target is ${formatMoney(input.revenueTarget)}; current forecast is ${formatMoney(input.currentForecast)}.`,
      logic: "This is the portion of the target that isn't even reflected in commit, best case, or open pipeline — it has no supporting activity yet.",
      commercialImplication: "Closing this gap requires generating and converting entirely new pipeline within the remaining period, not increasing confidence in existing pipeline.",
      revenueExposure: formatMoney(remainingTargetGap),
      nextInspection: "Separate a net-new pipeline generation plan from the forecast confidence conversation — they require different actions.",
    });
  }

  const slippageExposure = dim(dims, "slippageExposure");
  if (slippageExposure?.status === "SCORED" && slippageExposure.score !== null && slippageExposure.score < 60) {
    findings.push({
      id: "slippage-history",
      severity: slippageExposure.score < 40 ? "CRITICAL" : "HIGH",
      signal: "Deals in this pipeline have a demonstrated pattern of slipping.",
      evidence: slippageExposure.rationale,
      logic: "Repeated historical slippage or close-date pushes indicate the forecast period boundary is not being respected by the deals inside it.",
      commercialImplication: "Revenue currently forecast in this period is at meaningful risk of moving to the next one.",
      revenueExposure: "See Timing-Exposed tier in Revenue Exposure.",
      nextInspection: "Flag every opportunity with more than one historical push for a mid-cycle status review before period close.",
    });
  }

  return findings;
}

export function buildMissingData(input: ForecastAnalyzerInput, dims: DimensionResult[]): MissingDataItem[] {
  const items: MissingDataItem[] = [];
  for (const d of dims) {
    if (d.status === "INSUFFICIENT_EVIDENCE" && d.missingEvidence) {
      items.push({
        field: d.missingEvidence,
        why: `Required to score: ${d.name}.`,
        limits: d.rationale,
        wouldImprove: `Supplying this would allow ${d.name} to contribute to the Forecast Reliability Score instead of being excluded.`,
      });
    }
  }
  if (input.top3DealsValue === null) {
    items.push({
      field: "Top-3 combined deal value",
      why: "Sharpens concentration analysis beyond the single largest deal.",
      limits: "Concentration risk is currently assessed on the top-1 deal only.",
      wouldImprove: "Would show whether risk is isolated to one deal or spread across a handful.",
    });
  }
  if (input.previousForecast === null || input.previousActual === null) {
    if (input.historicalForecastAccuracyPct === null) {
      // already captured via dimension; skip duplicate
    }
  }
  return items;
}

function action(id: string, text: string, relatedFindingId: string): ActionItem {
  return { id, text, relatedFindingId };
}

export function buildActionPlan(
  findings: ReturnType<typeof buildFailureMap>,
  issues: IntegrityIssue[],
  missingData: MissingDataItem[],
): ActionPlan {
  const plan: ActionPlan = { now: [], next7Days: [], nextCycle: [], systemic: [] };

  const has = (id: string) => findings.some((f) => f.id === id);

  if (issues.some((i) => i.severity === "BLOCKING")) {
    plan.now.push(action("fix-blocking", "Correct the flagged data contradictions before this forecast is presented to leadership.", "data-integrity"));
  }
  if (has("forecast-discipline-break")) {
    plan.now.push(action("reconcile-figures", "Reconcile commit, best case, current forecast, and closed revenue against the source CRM report.", "forecast-discipline-break"));
  }
  if (has("concentration-risk")) {
    plan.now.push(action("confirm-top-deals", "Get a dated, named confirmation step on the top-1 and top-3 open opportunities today.", "concentration-risk"));
  }
  if (has("thin-coverage")) {
    plan.now.push(action("flag-coverage-gap", "Flag the remaining target gap to leadership now rather than at period close.", "thin-coverage"));
  }

  if (has("commit-underdelivers")) {
    plan.next7Days.push(action("audit-commit", "Audit each deal in commit against the specific disqualifiers behind past commit misses.", "commit-underdelivers"));
  }
  if (has("timing-risk")) {
    plan.next7Days.push(action("reverify-close-dates", "Re-verify close dates deal-by-deal for every opportunity older than the average sales cycle.", "timing-risk"));
  }
  if (has("slippage-history")) {
    plan.next7Days.push(action("review-pushed-deals", "Run a mid-cycle status review on every opportunity with more than one historical close-date push.", "slippage-history"));
  }
  if (has("conversion-below-history")) {
    plan.next7Days.push(action("test-conversion-driver", "Identify what specifically would justify converting pipeline above the historical win rate this period.", "conversion-below-history"));
  }
  if (has("coverage-masks-weak-evidence")) {
    plan.next7Days.push(action("requalify-pipeline", "Re-qualify the pipeline behind the coverage ratio, stage by stage.", "coverage-masks-weak-evidence"));
  }

  if (has("low-evidence-strength")) {
    plan.nextCycle.push(action("require-weighting", "Require stage-weighted pipeline reporting for all forecast contributions beyond commit.", "low-evidence-strength"));
  }
  if (has("unforecasted-whitespace")) {
    plan.nextCycle.push(action("separate-pipeline-gen", "Build a standalone net-new pipeline generation plan separate from forecast confidence review.", "unforecasted-whitespace"));
  }

  if (missingData.some((m) => m.field.toLowerCase().includes("historical forecast accuracy"))) {
    plan.systemic.push(action("track-forecast-accuracy", "Start tracking forecast-vs-actual by period so future cycles have historical forecast accuracy to score against.", "missing-data"));
  }
  if (missingData.some((m) => m.field.toLowerCase().includes("historical commit accuracy"))) {
    plan.systemic.push(action("track-commit-accuracy", "Start tracking commit-vs-close outcomes by rep and by period to validate commit going forward.", "missing-data"));
  }
  if (missingData.some((m) => m.field.toLowerCase().includes("win/conversion rate") || m.field.toLowerCase().includes("win rate"))) {
    plan.systemic.push(action("track-win-rate", "Instrument stage-to-close win rate reporting so conversion assumptions can be checked against history.", "missing-data"));
  }
  if (missingData.some((m) => m.field.toLowerCase().includes("slippage"))) {
    plan.systemic.push(action("track-slippage", "Track close-date movement per opportunity so slippage rate becomes a measurable input, not a guess.", "missing-data"));
  }

  return plan;
}
