import type { ForecastAnalyzerInput, ForecastAnalyzerResult, DimensionResult, EvidenceConfidence } from "./types";
import { validateForecastInput } from "./validate";
import { buildDimensions } from "./dimensions";
import { computeRevenueExposure, computeCoverage, computeConcentration, computeTimingRisk, computeScenarios } from "./exposure";
import { buildFailureMap, buildMissingData, buildActionPlan } from "./findings";
import { formatMoney } from "./format";

const HIGH_EVIDENCE_DIM_IDS = ["historicalAccuracy", "commitReliability", "conversionSupport"];
const MIN_SCORABLE_WEIGHT = 30;

function reliabilityBandFor(score: number): string {
  if (score >= 80) return "Durable";
  if (score >= 60) return "Directionally Sound";
  if (score >= 40) return "Fragile";
  return "Not Defensible";
}

function computeEvidenceConfidence(dims: DimensionResult[], blocked: boolean): { level: EvidenceConfidence; rationale: string } {
  if (blocked) {
    return {
      level: "LIMITED",
      rationale: "Contradictory inputs are blocking the diagnostic — evidence confidence cannot exceed Limited until they are corrected.",
    };
  }
  const scored = dims.filter((d) => d.status === "SCORED");
  const highScored = scored.filter((d) => HIGH_EVIDENCE_DIM_IDS.includes(d.id)).length;
  if (highScored >= 2 && scored.length >= 7) {
    return {
      level: "HIGH",
      rationale: `${highScored} of the 3 highest-evidence dimensions (historical forecast accuracy, commit reliability, conversion support) are scored, alongside ${scored.length} of ${dims.length} total dimensions.`,
    };
  }
  if (highScored >= 1 || scored.length >= 5) {
    return {
      level: "MODERATE",
      rationale: `${highScored} of the 3 highest-evidence dimensions are scored, with ${scored.length} of ${dims.length} total dimensions scored overall. Several conclusions rest on medium- or low-evidence inputs.`,
    };
  }
  return {
    level: "LIMITED",
    rationale: `Only ${scored.length} of ${dims.length} dimensions could be scored, and none of the highest-evidence dimensions (historical forecast accuracy, commit reliability, conversion support) had supporting data.`,
  };
}

export function runForecastDiagnostic(input: ForecastAnalyzerInput): ForecastAnalyzerResult {
  const integrityIssues = validateForecastInput(input);
  const blocked = integrityIssues.some((i) => i.severity === "BLOCKING");

  let dimensions = buildDimensions(input, integrityIssues);
  if (blocked) {
    dimensions = dimensions.map((d) => ({
      ...d,
      status: "INSUFFICIENT_EVIDENCE" as const,
      score: null,
      evidenceLevel: "N/A" as const,
      missingEvidence: "Withheld — contradictory inputs must be corrected first (see Data Integrity).",
    }));
  }

  const scoredDims = dimensions.filter((d) => d.status === "SCORED" && d.score !== null);
  const scoredWeight = scoredDims.reduce((sum, d) => sum + d.weight, 0);
  let reliabilityScore: number | null = null;
  if (!blocked && scoredWeight >= MIN_SCORABLE_WEIGHT) {
    const weightedSum = scoredDims.reduce((sum, d) => sum + (d.score as number) * d.weight, 0);
    reliabilityScore = Math.round(weightedSum / scoredWeight);
  }
  const reliabilityBand = reliabilityScore !== null ? reliabilityBandFor(reliabilityScore) : null;

  const { level: evidenceConfidence, rationale: evidenceConfidenceRationale } = computeEvidenceConfidence(dimensions, blocked);

  const { tiers: revenueExposure, remainingTargetGap } = computeRevenueExposure(input);
  const coverage = computeCoverage(input);
  const concentration = computeConcentration(input);
  const timing = computeTimingRisk(input);
  const { scenarios, note: scenarioNote } = computeScenarios(input, evidenceConfidence);

  const failureMap = blocked ? [] : buildFailureMap(input, dimensions, concentration, timing, coverage, remainingTargetGap, integrityIssues);
  const missingData = buildMissingData(input, dimensions);
  const actionPlan = buildActionPlan(failureMap, integrityIssues, missingData);

  const closedTier = revenueExposure.find((t) => t.id === "closedLocked");
  const commitValidatedTier = revenueExposure.find((t) => t.id === "commitValidated");
  const pipelineDependentTier = revenueExposure.find((t) => t.id === "pipelineDependent");
  const evidenceSupportedAmount =
    (closedTier?.amount ?? 0) +
    (commitValidatedTier?.amount ?? 0) +
    (pipelineDependentTier && pipelineDependentTier.evidenceLevel === "MEDIUM" ? pipelineDependentTier.amount ?? 0 : 0);
  const evidenceSupportedShare = input.currentForecast > 0 ? (evidenceSupportedAmount / input.currentForecast) * 100 : null;
  const revenueExposedAmount = blocked ? null : Math.max(input.currentForecast - evidenceSupportedAmount, 0);

  const sortedFindings = [...failureMap].sort((a, b) => {
    const rank = { CRITICAL: 0, HIGH: 1, MODERATE: 2 };
    return rank[a.severity] - rank[b.severity];
  });
  const topFinding = sortedFindings[0];

  const commitReliabilityDim = dimensions.find((d) => d.id === "commitReliability");
  const commitReliabilityLabel = blocked
    ? "Withheld pending data correction"
    : commitReliabilityDim?.status === "SCORED"
    ? `${commitReliabilityDim.score}/100 — historically validated`
    : "Unvalidated — no historical commit accuracy on file";

  const largestFragility = blocked
    ? "Contradictory inputs are blocking analysis — see Data Integrity."
    : topFinding
    ? topFinding.signal
    : "No material fragility identified from the inputs provided.";

  const riskiestAssumption = blocked
    ? "Resolve data integrity issues before any assumption can be assessed."
    : topFinding
    ? topFinding.logic
    : missingData[0]
    ? `${missingData[0].field} is unavailable — ${missingData[0].limits}`
    : "No single assumption stands out as materially riskier than the rest given the inputs provided.";

  const firstInspection = blocked
    ? "Correct the flagged data contradictions, then re-run the diagnostic."
    : topFinding
    ? topFinding.nextInspection
    : "Supply the optional historical evidence fields to sharpen this diagnosis further.";

  const result: ForecastAnalyzerResult = {
    generatedAt: new Date().toISOString(),
    input,
    integrityIssues,
    blocked,
    dimensions,
    reliabilityScore,
    reliabilityBand,
    evidenceConfidence,
    evidenceConfidenceRationale,
    scoredWeight,
    revenueExposure,
    coverage,
    concentration,
    timing,
    scenarios,
    scenarioNote,
    failureMap,
    missingData,
    actionPlan,
    executiveSummary: {
      currentForecast: input.currentForecast,
      evidenceSupportedAmount,
      evidenceSupportedShare,
      commitReliabilityLabel,
      largestFragility,
      revenueExposedAmount,
      riskiestAssumption,
      firstInspection,
    },
  };

  return result;
}

export { formatMoney };
