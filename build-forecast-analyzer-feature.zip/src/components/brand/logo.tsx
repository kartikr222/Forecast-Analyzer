import Image from "next/image";

const SIZE_MAP = {
  sm: { box: 56, tag: "text-[6px] px-1.5 py-0.5" },
  md: { box: 88, tag: "text-[8px] px-2 py-0.5" },
  lg: { box: 140, tag: "text-[10px] px-2.5 py-1" },
} as const;

type LogoSize = keyof typeof SIZE_MAP;

// Real dimensions of the source brand assets (public/brand), used to keep
// the lockup lockup's aspect ratio correct at any rendered height.
const LOCKUP_ASPECT = 1376 / 692;

/**
 * Circular badge lockup — the official Kartik Clarity™ brand mark
 * (public/brand/kc-badge.jpg), with a small rotated diagnostic tag
 * overlaid so each page can label the badge with its own context.
 */
export function KcBadgeLogo({ size = "md", tag, className = "" }: { size?: LogoSize; tag: string; className?: string }) {
  const s = SIZE_MAP[size];
  return (
    <div
      className={`relative shrink-0 overflow-visible rounded-full ${className}`}
      style={{ width: s.box, height: s.box }}
      role="img"
      aria-label={`Kartik Clarity™ — ${tag}`}
    >
      <div className="absolute inset-0 overflow-hidden rounded-full ring-2 ring-kc-navy-700">
        <Image
          src="/brand/kc-badge.jpg"
          alt="Kartik Clarity"
          fill
          sizes={`${s.box}px`}
          className="object-cover"
          priority
        />
      </div>
      <span
        className={`absolute -right-1 bottom-1 rotate-[8deg] rounded-sm bg-kc-cyan-300 font-semibold leading-tight text-kc-navy-900 shadow-sm ${s.tag}`}
      >
        {tag}
      </span>
    </div>
  );
}

/**
 * Horizontal lockup — the official Kartik Clarity™ banner asset
 * (public/brand/kc-lockup.jpg), used in navigation and print-style headers.
 */
export function KcLockupLogo({ tag, className = "", compact = false }: { tag: string; className?: string; compact?: boolean }) {
  const height = compact ? 40 : 56;
  const width = Math.round(height * LOCKUP_ASPECT);
  return (
    <div
      className={`relative shrink-0 overflow-hidden rounded-md ${className}`}
      style={{ width, height }}
      role="img"
      aria-label={`Kartik Clarity™ — ${tag}`}
    >
      <Image
        src="/brand/kc-lockup.jpg"
        alt="Kartik Clarity"
        fill
        sizes={`${width}px`}
        className="object-cover"
        priority
      />
    </div>
  );
}
