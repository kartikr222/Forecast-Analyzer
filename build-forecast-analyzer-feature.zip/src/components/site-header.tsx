"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { KcLockupLogo } from "@/components/brand/logo";

const NAV = [
  { href: "/", label: "Overview" },
  { href: "/pipeline-quality-scorer", label: "Pipeline Quality Scorer" },
  { href: "/pipeline-leak-detector", label: "Pipeline Leak Detector" },
  { href: "/forecast-analyzer", label: "Forecast Analyzer™" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 border-b border-kc-line bg-kc-paper/95 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
        <Link href="/" className="shrink-0" aria-label="Kartik Clarity™ home">
          <KcLockupLogo tag="Revenue Diagnostics" compact />
        </Link>

        <nav className="hidden items-center gap-1 md:flex" aria-label="Primary">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={`rounded-md px-3 py-2 text-sm font-medium transition-colors ${
                  active
                    ? "bg-kc-navy-900 text-white"
                    : "text-kc-navy-800 hover:bg-kc-paper-dim hover:text-kc-navy-900"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>

        <button
          type="button"
          onClick={() => setOpen((v) => !v)}
          className="inline-flex items-center justify-center rounded-md border border-kc-line p-2 text-kc-navy-900 md:hidden"
          aria-expanded={open}
          aria-label="Toggle navigation menu"
        >
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none" aria-hidden="true">
            <path d="M3 5h14M3 10h14M3 15h14" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
        </button>
      </div>

      {open && (
        <nav className="border-t border-kc-line bg-kc-paper px-4 py-2 md:hidden" aria-label="Primary mobile">
          {NAV.map((item) => {
            const active = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className={`block rounded-md px-3 py-2 text-sm font-medium ${
                  active ? "bg-kc-navy-900 text-white" : "text-kc-navy-800 hover:bg-kc-paper-dim"
                }`}
              >
                {item.label}
              </Link>
            );
          })}
        </nav>
      )}
    </header>
  );
}
