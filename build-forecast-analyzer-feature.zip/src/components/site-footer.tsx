import Link from "next/link";
import { KcBadgeLogo } from "@/components/brand/logo";

export function SiteFooter() {
  return (
    <footer className="border-t border-kc-line bg-kc-navy-950 text-kc-cyan-100">
      <div className="mx-auto flex max-w-6xl flex-col gap-8 px-4 py-12 sm:px-6 md:flex-row md:items-start md:justify-between">
        <div className="flex items-start gap-5">
          <KcBadgeLogo size="sm" tag="Revenue Diagnostics" />
          <div className="max-w-sm">
            <p className="kc-wordmark text-lg text-white">Kartik Clarity</p>
            <p className="mt-1 text-sm text-kc-cyan-200/80">
              Diagnostic instruments for revenue leaders who need to know what is actually true
              about their pipeline and their forecast — not what is comfortable to report.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-8 text-sm sm:grid-cols-3">
          <div>
            <p className="font-semibold text-white">Diagnostics</p>
            <ul className="mt-3 space-y-2 text-kc-cyan-200/80">
              <li><Link href="/pipeline-quality-scorer" className="hover:text-white">Pipeline Quality Scorer</Link></li>
              <li><Link href="/pipeline-leak-detector" className="hover:text-white">Pipeline Leak Detector</Link></li>
              <li><Link href="/forecast-analyzer" className="hover:text-white">Forecast Analyzer™</Link></li>
            </ul>
          </div>
          <div>
            <p className="font-semibold text-white">Product</p>
            <ul className="mt-3 space-y-2 text-kc-cyan-200/80">
              <li><Link href="/" className="hover:text-white">Overview</Link></li>
              <li><Link href="/forecast-analyzer#methodology" className="hover:text-white">Methodology</Link></li>
            </ul>
          </div>
        </div>
      </div>
      <div className="border-t border-white/10 px-4 py-4 text-center text-xs text-kc-cyan-200/60 sm:px-6">
        © {new Date().getFullYear()} Kartik Clarity™. Think. Focus. Achieve. All diagnostics are decision-support tools, not financial guarantees.
      </div>
    </footer>
  );
}
