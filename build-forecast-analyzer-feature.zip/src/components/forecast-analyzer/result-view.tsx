import type { ForecastAnalyzerResult, EvidenceLevel, FindingSeverity } from "@/lib/forecast-analyzer/types";
import { formatMoney, formatPct, formatRatio } from "@/lib/forecast-analyzer/format";
import { KcBadgeLogo } from "@/components/brand/logo";
import { CopyLinkButton } from "./copy-link-button";

const EVIDENCE_BADGE: Record<EvidenceLevel, string> = {
  HIGH: "bg-kc-green-bg text-kc-green",
  MEDIUM: "bg-kc-cyan-100 text-kc-blue-600",
  LOW: "bg-kc-amber-bg text-kc-amber",
  "N/A": "bg-kc-paper-dim text-kc-navy-800/60",
};

const SEVERITY_BADGE: Record<FindingSeverity, string> = {
  CRITICAL: "bg-kc-red-bg text-kc-red border-kc-red/30",
  HIGH: "bg-kc-amber-bg text-kc-amber border-kc-amber/30",
  MODERATE: "bg-kc-cyan-100 text-kc-blue-600 border-kc-blue-500/20",
};

const RISK_BADGE: Record<string, string> = {
  UNKNOWN: "bg-kc-paper-dim text-kc-navy-800/60",
  LOW: "bg-kc-green-bg text-kc-green",
  MODERATE: "bg-kc-cyan-100 text-kc-blue-600",
  HIGH: "bg-kc-amber-bg text-kc-amber",
  SEVERE: "bg-kc-red-bg text-kc-red",
};

function SectionCard({ id, title, subtitle, children }: { id?: string; title: string; subtitle?: string; children: React.ReactNode }) {
  return (
    <section id={id} className="rounded-2xl border border-kc-line bg-white p-6 sm:p-7">
      <h2 className="text-lg font-semibold text-kc-navy-900">{title}</h2>
      {subtitle && <p className="mt-1 text-sm text-kc-navy-800/70">{subtitle}</p>}
      <div className="mt-5">{children}</div>
    </section>
  );
}

export function ResultView({
  result,
  periodLabel,
  createdAt,
}: {
  result: ForecastAnalyzerResult;
  periodLabel: string;
  createdAt: string;
}) {
  const es = result.executiveSummary;

  return (
    <main>
      <section className="border-b border-kc-line bg-gradient-to-b from-kc-navy-950 to-kc-navy-800 text-white">
        <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div className="flex items-center gap-4">
              <KcBadgeLogo size="sm" tag="Forecast Analyzer™" />
              <div>
                <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-cyan-300">Forecast Reliability Diagnosis</p>
                <h1 className="mt-1 text-2xl font-semibold sm:text-3xl">{periodLabel}</h1>
                <p className="mt-1 text-xs text-kc-cyan-100/70">Generated {new Date(createdAt).toLocaleString()}</p>
              </div>
            </div>
            <CopyLinkButton />
          </div>

          {result.blocked ? (
            <div className="mt-8 rounded-xl border border-kc-red/40 bg-kc-red/10 p-5">
              <p className="text-sm font-semibold uppercase tracking-wide text-red-200">Diagnostic blocked</p>
              <p className="mt-2 text-sm text-white">
                Contradictory inputs prevent a defensible Forecast Reliability Score. Correct the
                issues in Data Integrity below, then re-run the diagnostic.
              </p>
            </div>
          ) : (
            <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <MetricTile label="Current forecast" value={formatMoney(es.currentForecast)} />
              <MetricTile
                label="Evidence-supported"
                value={formatMoney(es.evidenceSupportedAmount)}
                sub={es.evidenceSupportedShare !== null ? `${formatPct(es.evidenceSupportedShare, 1)} of forecast` : undefined}
              />
              <MetricTile label="Commit reliability" value={es.commitReliabilityLabel} small />
              <MetricTile label="Revenue exposed" value={es.revenueExposedAmount !== null ? formatMoney(es.revenueExposedAmount) : "—"} />
            </div>
          )}
        </div>
      </section>

      <div className="mx-auto max-w-5xl space-y-6 px-4 py-10 sm:px-6">
        {!result.blocked && (
          <SectionCard title="Executive read">
            <ol className="space-y-3 text-sm text-kc-navy-800/90">
              <SummaryLine n={1} q="Largest forecast fragility" a={es.largestFragility} />
              <SummaryLine n={2} q="Riskiest assumption" a={es.riskiestAssumption} />
              <SummaryLine n={3} q="What leadership should inspect first" a={es.firstInspection} />
            </ol>
          </SectionCard>
        )}

        {result.integrityIssues.length > 0 && (
          <SectionCard
            id="data-integrity"
            title="Data Integrity"
            subtitle="Contradictions are reported, never silently repaired. Each entry states what conclusion it limits."
          >
            <ul className="space-y-3">
              {result.integrityIssues.map((issue) => (
                <li
                  key={issue.id}
                  className={`rounded-lg border p-4 text-sm ${
                    issue.severity === "BLOCKING" ? "border-kc-red/40 bg-kc-red-bg" : "border-kc-amber/40 bg-kc-amber-bg"
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-kc-navy-900">{issue.field}</span>
                    <span
                      className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
                        issue.severity === "BLOCKING" ? "bg-kc-red text-white" : "bg-kc-amber text-white"
                      }`}
                    >
                      {issue.severity}
                    </span>
                  </div>
                  <p className="mt-1 text-kc-navy-800/85">{issue.message}</p>
                  <p className="mt-1 text-kc-navy-800/70">Limits: {issue.limits}</p>
                </li>
              ))}
            </ul>
          </SectionCard>
        )}

        {!result.blocked && (
          <>
            <SectionCard
              id="reliability"
              title="Forecast Reliability Score™"
              subtitle="Deterministic and reweighted to only the dimensions with sufficient evidence. Never implies certainty about future revenue."
            >
              <div className="flex flex-wrap items-end gap-6">
                <div>
                  <span className="text-5xl font-semibold kc-tabular text-kc-navy-900">
                    {result.reliabilityScore ?? "—"}
                    {result.reliabilityScore !== null && <span className="text-xl text-kc-navy-800/50">/100</span>}
                  </span>
                  {result.reliabilityBand && <p className="mt-1 text-sm font-semibold text-kc-blue-600">{result.reliabilityBand}</p>}
                </div>
                <div className="max-w-sm text-sm text-kc-navy-800/75">
                  {result.reliabilityScore === null
                    ? "Insufficient scored evidence weight to produce a defensible aggregate score — review the individual dimensions below."
                    : `Based on ${result.scoredWeight} of 100 possible weight points, reweighted to 100%. Dimensions without sufficient evidence were excluded rather than estimated.`}
                </div>
              </div>

              <div className="mt-6 space-y-3">
                {result.dimensions.map((d) => (
                  <div key={d.id} className="rounded-lg border border-kc-line p-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="font-medium text-kc-navy-900">{d.name}</span>
                        <span className="ml-2 text-xs text-kc-navy-800/60">weight {d.weight}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${EVIDENCE_BADGE[d.evidenceLevel]}`}>
                          {d.evidenceLevel}
                        </span>
                        <span className="kc-tabular text-sm font-semibold text-kc-navy-900">
                          {d.status === "SCORED" ? `${d.score}/100` : "INSUFFICIENT EVIDENCE"}
                        </span>
                      </div>
                    </div>
                    <p className="mt-1 text-xs italic text-kc-navy-800/60">{d.question}</p>
                    <p className="mt-2 text-sm text-kc-navy-800/85">{d.rationale}</p>
                  </div>
                ))}
              </div>
            </SectionCard>

            <SectionCard
              title="Evidence Confidence"
              subtitle="Kept separate from the Forecast Reliability Score by design — a forecast can be high-reliability with limited evidence, or moderate-reliability with strong evidence."
            >
              <div className="flex flex-wrap items-center gap-4">
                <span
                  className={`rounded-full px-4 py-1.5 text-sm font-semibold ${
                    result.evidenceConfidence === "HIGH"
                      ? "bg-kc-green-bg text-kc-green"
                      : result.evidenceConfidence === "MODERATE"
                      ? "bg-kc-cyan-100 text-kc-blue-600"
                      : "bg-kc-amber-bg text-kc-amber"
                  }`}
                >
                  {result.evidenceConfidence}
                </span>
                <p className="max-w-2xl text-sm text-kc-navy-800/80">{result.evidenceConfidenceRationale}</p>
              </div>
            </SectionCard>

            <SectionCard title="Revenue Exposure" subtitle="Every tier traces from input → formula → result → interpretation.">
              <div className="overflow-x-auto">
                <table className="w-full min-w-[640px] text-sm">
                  <thead>
                    <tr className="border-b border-kc-line text-left text-xs uppercase tracking-wide text-kc-navy-800/60">
                      <th className="py-2 pr-3">Tier</th>
                      <th className="py-2 pr-3">Amount</th>
                      <th className="py-2 pr-3">Evidence</th>
                      <th className="py-2 pr-3">Formula</th>
                      <th className="py-2">Interpretation</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.revenueExposure.map((tier) => (
                      <tr key={tier.id} className="border-b border-kc-line/60 align-top">
                        <td className="py-3 pr-3 font-medium text-kc-navy-900">{tier.label}</td>
                        <td className="py-3 pr-3 kc-tabular font-semibold text-kc-navy-900">{formatMoney(tier.amount)}</td>
                        <td className="py-3 pr-3">
                          <span className={`rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase ${EVIDENCE_BADGE[tier.evidenceLevel]}`}>
                            {tier.evidenceLevel}
                          </span>
                        </td>
                        <td className="py-3 pr-3 text-xs text-kc-navy-800/70">{tier.formula}</td>
                        <td className="py-3 text-xs text-kc-navy-800/70">{tier.interpretation}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </SectionCard>

            <div className="grid gap-6 md:grid-cols-2">
              <SectionCard title="Pipeline Coverage">
                <p className="text-3xl font-semibold kc-tabular text-kc-navy-900">{formatRatio(result.coverage.ratio, 2)}</p>
                <p className="mt-2 text-sm text-kc-navy-800/80">{result.coverage.note}</p>
                <p className="mt-3 rounded-lg bg-kc-paper-dim p-3 text-xs text-kc-navy-800/70">
                  Coverage is never treated as a proxy for reliability on its own — cross-read it against Conversion Support and Stage Evidence above.
                </p>
              </SectionCard>

              <SectionCard title="Concentration Analysis">
                <div className="flex items-center gap-3">
                  <span className={`rounded-full px-3 py-1 text-xs font-semibold uppercase ${RISK_BADGE[result.concentration.riskLevel]}`}>
                    {result.concentration.riskLevel}
                  </span>
                  {result.concentration.top1SharePipeline !== null && (
                    <span className="kc-tabular text-2xl font-semibold text-kc-navy-900">{formatPct(result.concentration.top1SharePipeline, 1)}</span>
                  )}
                </div>
                <p className="mt-3 text-sm text-kc-navy-800/80">{result.concentration.narrative}</p>
              </SectionCard>
            </div>

            <SectionCard title="Timing Risk Profile">
              <div className="flex items-center gap-3">
                <span className={`rounded-full px-3 py-1 text-xs font-semibold uppercase ${RISK_BADGE[result.timing.riskLevel]}`}>
                  {result.timing.riskLevel}
                </span>
              </div>
              <p className="mt-3 text-sm text-kc-navy-800/80">{result.timing.narrative}</p>
            </SectionCard>

            {result.scenarios && (
              <SectionCard title="Scenario Analysis" subtitle="Analytical cases, not predictions.">
                <div className="grid gap-4 sm:grid-cols-3">
                  {result.scenarios.map((s) => (
                    <div key={s.id} className="rounded-xl border border-kc-line p-4">
                      <p className="text-xs font-semibold uppercase tracking-wide text-kc-blue-600">{s.label}</p>
                      <p className="mt-2 text-2xl font-semibold kc-tabular text-kc-navy-900">{formatMoney(s.amount)}</p>
                      <ul className="mt-3 space-y-1 text-xs text-kc-navy-800/70">
                        {s.assumptions.map((a, i) => (
                          <li key={i}>• {a}</li>
                        ))}
                      </ul>
                    </div>
                  ))}
                </div>
                {result.scenarioNote && <p className="mt-4 text-sm italic text-kc-navy-800/70">{result.scenarioNote}</p>}
              </SectionCard>
            )}

            <SectionCard
              title="Where This Forecast Could Break"
              subtitle="Every finding is generated only from the inputs you supplied."
            >
              {result.failureMap.length === 0 ? (
                <p className="text-sm text-kc-navy-800/70">No material fragility signals were generated from the inputs provided.</p>
              ) : (
                <div className="space-y-4">
                  {result.failureMap.map((f) => (
                    <div key={f.id} className={`rounded-xl border p-4 ${SEVERITY_BADGE[f.severity]}`}>
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-semibold text-kc-navy-900">{f.signal}</span>
                        <span className="rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase">{f.severity}</span>
                      </div>
                      <dl className="mt-3 space-y-1.5 text-sm text-kc-navy-800/85">
                        <FindingRow label="Evidence" value={f.evidence} />
                        <FindingRow label="Logic" value={f.logic} />
                        <FindingRow label="Commercial implication" value={f.commercialImplication} />
                        <FindingRow label="Revenue exposure" value={f.revenueExposure} />
                        <FindingRow label="Next inspection" value={f.nextInspection} />
                      </dl>
                    </div>
                  ))}
                </div>
              )}
            </SectionCard>
          </>
        )}

        {result.missingData.length > 0 && (
          <SectionCard title="Missing Data Intelligence" subtitle="What's missing, why it matters, and what it would improve.">
            <ul className="space-y-3">
              {result.missingData.map((m, i) => (
                <li key={i} className="rounded-lg border border-kc-line p-4 text-sm">
                  <p className="font-medium text-kc-navy-900">{m.field}</p>
                  <p className="mt-1 text-kc-navy-800/80">{m.limits}</p>
                  <p className="mt-1 text-kc-navy-800/60">Would improve: {m.wouldImprove}</p>
                </li>
              ))}
            </ul>
          </SectionCard>
        )}

        {!result.blocked && (
          <SectionCard title="Action Plan" subtitle="Every action maps to a specific finding above.">
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              <ActionColumn title="Now" items={result.actionPlan.now} />
              <ActionColumn title="Next 7 days" items={result.actionPlan.next7Days} />
              <ActionColumn title="Next forecast cycle" items={result.actionPlan.nextCycle} />
              <ActionColumn title="Systemic" items={result.actionPlan.systemic} />
            </div>
          </SectionCard>
        )}

        <SectionCard id="methodology" title="Methodology">
          <div className="space-y-3 text-sm text-kc-navy-800/80">
            <p>
              The Forecast Reliability Score™ is a weighted average of up to ten dimensions, each
              scored 0–100 from a deterministic formula applied to the inputs you supplied. A
              dimension without the evidence it requires is excluded from the score entirely — its
              weight is redistributed across the dimensions that could be scored — rather than
              assigned a fabricated midpoint.
            </p>
            <p>
              Evidence Confidence is calculated separately from the score, based on how many of the
              three highest-evidence dimensions (Historical Forecast Accuracy, Commit Reliability,
              Conversion Support) had supporting data, and how many of the ten dimensions overall
              could be scored. A high score with limited evidence, or a moderate score with high
              evidence, are both valid and meaningfully different outcomes.
            </p>
            <p>
              Revenue Exposure tiers are computed directly from your inputs using the formulas shown
              in each row — no probability, benchmark, or industry average is ever invented to fill a
              gap. Where a tier cannot be computed from the data provided, it is shown as
              not-quantifiable rather than estimated.
            </p>
          </div>
        </SectionCard>
      </div>
    </main>
  );
}

function MetricTile({ label, value, sub, small }: { label: string; value: string; sub?: string; small?: boolean }) {
  return (
    <div className="rounded-xl border border-white/15 bg-white/5 p-4">
      <p className="text-xs uppercase tracking-wide text-kc-cyan-200/80">{label}</p>
      <p className={`mt-1 font-semibold kc-tabular ${small ? "text-base" : "text-2xl"}`}>{value}</p>
      {sub && <p className="mt-0.5 text-xs text-kc-cyan-200/70">{sub}</p>}
    </div>
  );
}

function SummaryLine({ n, q, a }: { n: number; q: string; a: string }) {
  return (
    <li className="flex gap-3">
      <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-kc-navy-900 text-[11px] font-semibold text-white">
        {n}
      </span>
      <div>
        <span className="font-medium text-kc-navy-900">{q}: </span>
        <span>{a}</span>
      </div>
    </li>
  );
}

function FindingRow({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="inline text-xs font-semibold uppercase tracking-wide text-kc-navy-800/60">{label}: </dt>
      <dd className="inline">{value}</dd>
    </div>
  );
}

function ActionColumn({ title, items }: { title: string; items: { id: string; text: string }[] }) {
  return (
    <div>
      <p className="text-xs font-semibold uppercase tracking-wide text-kc-blue-600">{title}</p>
      {items.length === 0 ? (
        <p className="mt-2 text-xs text-kc-navy-800/50">No actions triggered.</p>
      ) : (
        <ul className="mt-2 space-y-2">
          {items.map((a) => (
            <li key={a.id} className="rounded-lg bg-kc-paper-dim p-2.5 text-xs text-kc-navy-800/85">
              {a.text}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
