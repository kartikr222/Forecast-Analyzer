import { pgTable, uuid, timestamp, jsonb, text, integer } from "drizzle-orm/pg-core";
import type { ForecastAnalyzerInput, ForecastAnalyzerResult } from "@/lib/forecast-analyzer/types";

export const forecastAnalyses = pgTable("forecast_analyses", {
  id: uuid("id").primaryKey().defaultRandom(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  forecastPeriodLabel: text("forecast_period_label").notNull(),
  reliabilityScore: integer("reliability_score"),
  input: jsonb("input").$type<ForecastAnalyzerInput>().notNull(),
  result: jsonb("result").$type<ForecastAnalyzerResult>().notNull(),
});
