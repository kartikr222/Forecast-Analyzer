"use client";

import { useState } from "react";
import Link from "next/link";
import { scorePipelineQuality, type PipelineQualityInput, type PipelineQualityResult } from "@/lib/pipeline-quality/engine";

type FormState = Record<keyof PipelineQualityInput, string>;

const EMPTY: FormState = {
  openPipelineValue: "",
  numOpenOpportunities: "",
  earlyStageValue: "",
  midStageValue: "",
  lateStageValue: "",
  avgOpportunityAgeDays: "",
  avgSalesCycleDays: "",
  staleOpportunities: "",
  multiThreadedOpportunities: "",
};

function toNum(v: string): number | null {
  if (v.trim() === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

export default function PipelineQualityScorerPage() {
  const [form, setForm] = useState<FormState>(EMPTY);
  const [result, setResult] = useState<PipelineQualityResult | null>(null);

  const set = (key: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const input: PipelineQualityInput = {
      openPipelineValue: toNum(form.openPipelineValue) ?? 0,
      numOpenOpportunities: toNum(form.numOpenOpportunities) ?? 0,
      earlyStageValue: toNum(form.earlyStageValue) ?? 0,
      midStageValue: toNum(form.midStageValue) ?? 0,
      lateStageValue: toNum(form.lateStageValue) ?? 0,
      avgOpportunityAgeDays: toNum(form.avgOpportunityAgeDays),
      avgSalesCycleDays: toNum(form.avgSalesCycleDays),
      staleOpportunities: toNum(form.staleOpportunities),
      multiThreadedOpportunities: toNum(form.multiThreadedOpportunities),
    };
    setResult(scorePipelineQuality(input));
  };

  return (
    <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-blue-600">Kartik Clarity™ · Pipeline Quality Scorer</p>
      <h1 className="mt-3 text-3xl font-semibold text-kc-navy-900 sm:text-4xl">How healthy and strong is the pipeline?</h1>
      <p className="mt-4 max-w-2xl text-sm leading-relaxed text-kc-navy-800/80">
        This instrument scores the structural condition of open pipeline — stage mix, aging,
        hygiene, and engagement depth. It does not evaluate a forecast number; for forecast
        trustworthiness use{" "}
        <Link href="/forecast-analyzer" className="font-semibold text-kc-blue-600 underline">
          Forecast Analyzer™
        </Link>
        .
      </p>

      <form onSubmit={submit} className="mt-8 grid gap-4 rounded-2xl border border-kc-line bg-white p-6 sm:grid-cols-2">
        <Field label="Open pipeline value ($)" value={form.openPipelineValue} onChange={set("openPipelineValue")} required />
        <Field label="Open opportunity count" value={form.numOpenOpportunities} onChange={set("numOpenOpportunities")} required />
        <Field label="Early-stage value ($)" value={form.earlyStageValue} onChange={set("earlyStageValue")} required />
        <Field label="Mid-stage value ($)" value={form.midStageValue} onChange={set("midStageValue")} required />
        <Field label="Late-stage value ($)" value={form.lateStageValue} onChange={set("lateStageValue")} required />
        <Field label="Avg. opportunity age (days) — optional" value={form.avgOpportunityAgeDays} onChange={set("avgOpportunityAgeDays")} />
        <Field label="Avg. sales cycle (days) — optional" value={form.avgSalesCycleDays} onChange={set("avgSalesCycleDays")} />
        <Field label="Stale opportunities (no activity 30d) — optional" value={form.staleOpportunities} onChange={set("staleOpportunities")} />
        <Field label="Multi-threaded opportunities — optional" value={form.multiThreadedOpportunities} onChange={set("multiThreadedOpportunities")} />
        <div className="sm:col-span-2">
          <button type="submit" className="rounded-md bg-kc-navy-900 px-5 py-3 text-sm font-semibold text-white hover:bg-kc-navy-800">
            Score this pipeline
          </button>
        </div>
      </form>

      {result && (
        <section className="mt-10 rounded-2xl border border-kc-line bg-white p-6">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <h2 className="text-lg font-semibold text-kc-navy-900">Pipeline Quality Score</h2>
            <span className="text-3xl font-semibold kc-tabular text-kc-navy-900">
              {result.qualityScore ?? "—"}
              {result.qualityScore !== null && <span className="text-base text-kc-navy-800/60">/100</span>}
            </span>
          </div>
          {result.band && <p className="mt-1 text-sm font-medium text-kc-blue-600">{result.band}</p>}

          <div className="mt-6 space-y-3">
            {result.dimensions.map((d) => (
              <div key={d.id} className="rounded-lg border border-kc-line p-4">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-kc-navy-900">{d.name}</span>
                  <span className="kc-tabular text-sm font-semibold text-kc-navy-900">
                    {d.status === "SCORED" ? `${d.score}/100` : "INSUFFICIENT EVIDENCE"}
                  </span>
                </div>
                <p className="mt-1 text-sm text-kc-navy-800/75">{d.rationale}</p>
              </div>
            ))}
          </div>
          {result.notes.length > 0 && (
            <div className="mt-4 rounded-lg bg-kc-amber-bg p-4 text-sm text-kc-amber">
              {result.notes.map((n, i) => (
                <p key={i}>{n}</p>
              ))}
            </div>
          )}
        </section>
      )}
    </main>
  );
}

function Field({
  label,
  value,
  onChange,
  required,
}: {
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean;
}) {
  return (
    <label className="flex flex-col gap-1 text-sm">
      <span className="font-medium text-kc-navy-900">{label}</span>
      <input
        type="number"
        value={value}
        onChange={onChange}
        required={required}
        className="rounded-md border border-kc-line px-3 py-2 text-sm focus:border-kc-blue-500"
      />
    </label>
  );
}
