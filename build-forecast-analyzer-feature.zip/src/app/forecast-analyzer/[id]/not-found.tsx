import Link from "next/link";

export default function NotFound() {
  return (
    <main className="mx-auto max-w-xl px-4 py-24 text-center sm:px-6">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-blue-600">Forecast Analyzer™</p>
      <h1 className="mt-3 text-2xl font-semibold text-kc-navy-900">Diagnostic not found</h1>
      <p className="mt-3 text-sm text-kc-navy-800/75">
        This result link doesn&apos;t match a saved diagnostic. It may have used an invalid ID or the
        record no longer exists.
      </p>
      <Link href="/forecast-analyzer" className="mt-6 inline-block rounded-md bg-kc-navy-900 px-5 py-3 text-sm font-semibold text-white">
        Run a new diagnostic
      </Link>
    </main>
  );
}
