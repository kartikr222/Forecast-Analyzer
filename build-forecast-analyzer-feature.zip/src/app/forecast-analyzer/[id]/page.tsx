import { eq } from "drizzle-orm";
import { notFound } from "next/navigation";
import { db } from "@/db";
import { forecastAnalyses } from "@/db/schema";
import { ResultView } from "@/components/forecast-analyzer/result-view";

export const dynamic = "force-dynamic";

export default async function ForecastAnalyzerResultPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;

  const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  if (!uuidPattern.test(id)) {
    notFound();
  }

  const rows = await db.select().from(forecastAnalyses).where(eq(forecastAnalyses.id, id)).limit(1);
  const row = rows[0];

  if (!row) {
    notFound();
  }

  return <ResultView result={row.result} periodLabel={row.forecastPeriodLabel} createdAt={row.createdAt.toISOString()} />;
}
