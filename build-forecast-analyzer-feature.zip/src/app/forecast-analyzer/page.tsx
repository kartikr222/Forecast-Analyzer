import type { Metadata } from "next";
import { KcBadgeLogo } from "@/components/brand/logo";
import { ForecastForm } from "./forecast-form";

export const metadata: Metadata = {
  title: "Forecast Analyzer™ | Kartik Clarity™",
  description: "Pressure-test the revenue forecast you report to leadership — evidence, assumptions, risk, and exposure.",
};

export default function ForecastAnalyzerPage() {
  return (
    <main>
      <section className="border-b border-kc-line bg-gradient-to-b from-kc-navy-950 to-kc-navy-800 text-white">
        <div className="mx-auto flex max-w-5xl flex-col gap-8 px-4 py-14 sm:px-6 md:flex-row md:items-center">
          <KcBadgeLogo size="md" tag="Forecast Analyzer™" className="hidden sm:block" />
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-cyan-300">Kartik Clarity™ · Forecast Analyzer™</p>
            <h1 className="mt-3 text-[clamp(1.8rem,4vw,2.6rem)] font-semibold leading-tight">
              How trustworthy is the forecast you&apos;re about to report?
            </h1>
            <p className="mt-4 max-w-2xl text-sm text-kc-cyan-100/90 sm:text-base">
              This is not a pipeline health check. It pressure-tests the specific number being
              reported upward — separating what is evidence, what is assumption, what is exposed,
              and where it is most likely to break.
            </p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-4 py-12 sm:px-6">
        <div className="mb-8 grid gap-3 rounded-2xl border border-kc-line bg-kc-paper-dim p-5 text-sm text-kc-navy-800/85 sm:grid-cols-2">
          <p>
            <span className="font-semibold text-kc-navy-900">Unknown stays unknown.</span> Leave any
            optional field blank and it is treated as missing evidence — never as zero, never
            fabricated.
          </p>
          <p>
            <span className="font-semibold text-kc-navy-900">Every field is evidence-tagged.</span>{" "}
            HIGH / MEDIUM / LOW badges show what tier of evidence each input feeds into the diagnosis.
          </p>
        </div>
        <ForecastForm />
      </section>
    </main>
  );
}
