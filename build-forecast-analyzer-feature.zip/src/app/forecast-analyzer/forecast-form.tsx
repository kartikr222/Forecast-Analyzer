"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import type { ForecastAnalyzerInput } from "@/lib/forecast-analyzer/types";

type FieldKey = Exclude<keyof ForecastAnalyzerInput, "forecastPeriodLabel">;
type FormState = { forecastPeriodLabel: string } & Record<FieldKey, string>;

const EMPTY_FORM: FormState = {
  forecastPeriodLabel: "",
  revenueTarget: "",
  closedRevenue: "",
  currentForecast: "",
  commit: "",
  openPipeline: "",
  bestCase: "",
  weightedPipeline: "",
  previousForecast: "",
  previousActual: "",
  historicalForecastAccuracyPct: "",
  historicalWinRatePct: "",
  historicalCommitAccuracyPct: "",
  historicalSlippageRatePct: "",
  avgSalesCycleDays: "",
  avgOpportunityAgeDays: "",
  daysRemainingInPeriod: "",
  closeDatePushes: "",
  numOpenOpportunities: "",
  dealsInCommit: "",
  top1DealValue: "",
  top3DealsValue: "",
  lateStagePipelineValue: "",
};

function toNullableNumber(v: string): number | null {
  if (v.trim() === "") return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

export function ForecastForm() {
  const router = useRouter();
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [showHistorical, setShowHistorical] = useState(false);
  const [showStructure, setShowStructure] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const update = (key: keyof FormState) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const requiredMissing = ["forecastPeriodLabel", "revenueTarget", "closedRevenue", "currentForecast", "commit", "openPipeline"].filter(
      (k) => form[k as keyof FormState].trim() === "",
    );
    if (requiredMissing.length > 0) {
      setError("Complete every field in Forecast Basics before running the diagnostic.");
      return;
    }

    const payload: ForecastAnalyzerInput = {
      forecastPeriodLabel: form.forecastPeriodLabel.trim(),
      revenueTarget: Number(form.revenueTarget),
      closedRevenue: Number(form.closedRevenue),
      currentForecast: Number(form.currentForecast),
      commit: Number(form.commit),
      openPipeline: Number(form.openPipeline),
      bestCase: toNullableNumber(form.bestCase),
      weightedPipeline: toNullableNumber(form.weightedPipeline),
      previousForecast: toNullableNumber(form.previousForecast),
      previousActual: toNullableNumber(form.previousActual),
      historicalForecastAccuracyPct: toNullableNumber(form.historicalForecastAccuracyPct),
      historicalWinRatePct: toNullableNumber(form.historicalWinRatePct),
      historicalCommitAccuracyPct: toNullableNumber(form.historicalCommitAccuracyPct),
      historicalSlippageRatePct: toNullableNumber(form.historicalSlippageRatePct),
      avgSalesCycleDays: toNullableNumber(form.avgSalesCycleDays),
      avgOpportunityAgeDays: toNullableNumber(form.avgOpportunityAgeDays),
      daysRemainingInPeriod: toNullableNumber(form.daysRemainingInPeriod),
      closeDatePushes: toNullableNumber(form.closeDatePushes),
      numOpenOpportunities: toNullableNumber(form.numOpenOpportunities),
      dealsInCommit: toNullableNumber(form.dealsInCommit),
      top1DealValue: toNullableNumber(form.top1DealValue),
      top3DealsValue: toNullableNumber(form.top3DealsValue),
      lateStagePipelineValue: toNullableNumber(form.lateStagePipelineValue),
    };

    setSubmitting(true);
    try {
      const res = await fetch("/api/forecast-analyzer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? "The diagnostic could not be run. Please check your inputs.");
        setSubmitting(false);
        return;
      }
      router.push(`/forecast-analyzer/${data.id}`);
    } catch {
      setError("Network error — the diagnostic could not be submitted.");
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <fieldset className="rounded-2xl border border-kc-line bg-white p-6">
        <legend className="px-1 text-sm font-semibold uppercase tracking-wide text-kc-blue-600">Forecast Basics — required</legend>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <TextField label="Forecast period" placeholder="e.g. Q1 FY26" value={form.forecastPeriodLabel} onChange={update("forecastPeriodLabel")} required />
          <NumberField label="Revenue target ($)" value={form.revenueTarget} onChange={update("revenueTarget")} required evidence="MEDIUM" />
          <NumberField label="Closed revenue ($)" value={form.closedRevenue} onChange={update("closedRevenue")} required evidence="HIGH" />
          <NumberField label="Current forecast being reported ($)" value={form.currentForecast} onChange={update("currentForecast")} required evidence="LOW" />
          <NumberField label="Commit ($)" value={form.commit} onChange={update("commit")} required evidence="LOW" />
          <NumberField label="Open / qualified pipeline ($)" value={form.openPipeline} onChange={update("openPipeline")} required evidence="MEDIUM" />
          <NumberField label="Best case ($) — optional" value={form.bestCase} onChange={update("bestCase")} evidence="LOW" />
          <NumberField label="Weighted pipeline ($) — optional" value={form.weightedPipeline} onChange={update("weightedPipeline")} evidence="MEDIUM" />
        </div>
      </fieldset>

      <DisclosureSection
        title="Historical Performance"
        subtitle="Strengthens Historical Forecast Accuracy, Commit Reliability, Conversion Support, and Slippage Exposure. Leave unknown fields blank — they will show as insufficient evidence, never as zero."
        open={showHistorical}
        onToggle={() => setShowHistorical((v) => !v)}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <NumberField label="Previous period forecast ($)" value={form.previousForecast} onChange={update("previousForecast")} evidence="HIGH" />
          <NumberField label="Previous period actual ($)" value={form.previousActual} onChange={update("previousActual")} evidence="HIGH" />
          <NumberField label="Historical forecast accuracy (%)" value={form.historicalForecastAccuracyPct} onChange={update("historicalForecastAccuracyPct")} evidence="HIGH" />
          <NumberField label="Historical win / conversion rate (%)" value={form.historicalWinRatePct} onChange={update("historicalWinRatePct")} evidence="HIGH" />
          <NumberField label="Historical commit accuracy (%)" value={form.historicalCommitAccuracyPct} onChange={update("historicalCommitAccuracyPct")} evidence="HIGH" />
          <NumberField label="Historical slippage rate (%)" value={form.historicalSlippageRatePct} onChange={update("historicalSlippageRatePct")} evidence="HIGH" />
        </div>
      </DisclosureSection>

      <DisclosureSection
        title="Pipeline Structure & Timing"
        subtitle="Strengthens Timing Confidence, Stage Evidence, Concentration Exposure, and the Revenue Exposure breakdown."
        open={showStructure}
        onToggle={() => setShowStructure((v) => !v)}
      >
        <div className="grid gap-4 sm:grid-cols-2">
          <NumberField label="Average sales cycle (days)" value={form.avgSalesCycleDays} onChange={update("avgSalesCycleDays")} evidence="MEDIUM" />
          <NumberField label="Average opportunity age (days)" value={form.avgOpportunityAgeDays} onChange={update("avgOpportunityAgeDays")} evidence="MEDIUM" />
          <NumberField label="Days remaining in forecast period" value={form.daysRemainingInPeriod} onChange={update("daysRemainingInPeriod")} evidence="MEDIUM" />
          <NumberField label="Close-date pushes (count)" value={form.closeDatePushes} onChange={update("closeDatePushes")} evidence="MEDIUM" />
          <NumberField label="Open opportunity count" value={form.numOpenOpportunities} onChange={update("numOpenOpportunities")} evidence="MEDIUM" />
          <NumberField label="Deals included in commit (count)" value={form.dealsInCommit} onChange={update("dealsInCommit")} evidence="LOW" />
          <NumberField label="Top-1 (largest) deal value ($)" value={form.top1DealValue} onChange={update("top1DealValue")} evidence="MEDIUM" />
          <NumberField label="Top-3 combined deal value ($)" value={form.top3DealsValue} onChange={update("top3DealsValue")} evidence="MEDIUM" />
          <NumberField label="Late-stage pipeline value ($)" value={form.lateStagePipelineValue} onChange={update("lateStagePipelineValue")} evidence="MEDIUM" />
        </div>
      </DisclosureSection>

      {error && (
        <div role="alert" className="rounded-lg border border-kc-red bg-kc-red-bg px-4 py-3 text-sm text-kc-red">
          {error}
        </div>
      )}

      <button
        type="submit"
        disabled={submitting}
        className="w-full rounded-md bg-kc-navy-900 px-5 py-4 text-sm font-semibold text-white transition-colors hover:bg-kc-navy-800 disabled:opacity-60 sm:w-auto"
      >
        {submitting ? "Running diagnostic…" : "Pressure-test this forecast"}
      </button>
    </form>
  );
}

function DisclosureSection({
  title,
  subtitle,
  open,
  onToggle,
  children,
}: {
  title: string;
  subtitle: string;
  open: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="rounded-2xl border border-kc-line bg-white p-6">
      <button type="button" onClick={onToggle} className="flex w-full items-center justify-between text-left" aria-expanded={open}>
        <div>
          <span className="text-sm font-semibold uppercase tracking-wide text-kc-blue-600">{title} — optional</span>
          <p className="mt-1 max-w-2xl text-xs text-kc-navy-800/70">{subtitle}</p>
        </div>
        <span className="ml-4 shrink-0 rounded-full border border-kc-line px-3 py-1 text-xs font-semibold text-kc-navy-900">
          {open ? "Hide" : "Add data"}
        </span>
      </button>
      {open && <div className="mt-5">{children}</div>}
    </div>
  );
}

function TextField({
  label,
  value,
  onChange,
  required,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean;
  placeholder?: string;
}) {
  return (
    <label className="flex flex-col gap-1.5 text-sm">
      <span className="font-medium text-kc-navy-900">
        {label} {required && <span className="text-kc-red">*</span>}
      </span>
      <input
        type="text"
        value={value}
        onChange={onChange}
        required={required}
        placeholder={placeholder}
        className="rounded-md border border-kc-line px-3 py-2 text-sm text-kc-navy-900 focus:border-kc-blue-500"
      />
    </label>
  );
}

const EVIDENCE_STYLES: Record<string, string> = {
  HIGH: "bg-kc-green-bg text-kc-green",
  MEDIUM: "bg-kc-cyan-100 text-kc-blue-600",
  LOW: "bg-kc-amber-bg text-kc-amber",
};

function NumberField({
  label,
  value,
  onChange,
  required,
  evidence,
}: {
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  required?: boolean;
  evidence: "HIGH" | "MEDIUM" | "LOW";
}) {
  return (
    <label className="flex flex-col gap-1.5 text-sm">
      <span className="flex items-center justify-between gap-2">
        <span className="font-medium text-kc-navy-900">
          {label} {required && <span className="text-kc-red">*</span>}
        </span>
        <span className={`shrink-0 rounded px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${EVIDENCE_STYLES[evidence]}`}>
          {evidence}
        </span>
      </span>
      <input
        type="number"
        step="any"
        value={value}
        onChange={onChange}
        required={required}
        placeholder={required ? "0" : "Unknown"}
        className="rounded-md border border-kc-line px-3 py-2 text-sm text-kc-navy-900 focus:border-kc-blue-500"
      />
    </label>
  );
}
