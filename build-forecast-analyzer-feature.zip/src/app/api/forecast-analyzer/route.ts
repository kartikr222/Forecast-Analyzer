import { db } from "@/db";
import { forecastAnalyses } from "@/db/schema";
import { runForecastDiagnostic } from "@/lib/forecast-analyzer/engine";
import type { ForecastAnalyzerInput } from "@/lib/forecast-analyzer/types";

export const dynamic = "force-dynamic";

function isFiniteNumber(v: unknown): v is number {
  return typeof v === "number" && Number.isFinite(v);
}

function isNullableNumber(v: unknown): v is number | null {
  return v === null || isFiniteNumber(v);
}

function parseInput(body: unknown): { ok: true; input: ForecastAnalyzerInput } | { ok: false; error: string } {
  if (typeof body !== "object" || body === null) return { ok: false, error: "Request body must be a JSON object." };
  const b = body as Record<string, unknown>;

  if (typeof b.forecastPeriodLabel !== "string" || b.forecastPeriodLabel.trim().length === 0) {
    return { ok: false, error: "forecastPeriodLabel is required." };
  }

  const requiredNumeric: Array<keyof ForecastAnalyzerInput> = [
    "revenueTarget",
    "closedRevenue",
    "currentForecast",
    "commit",
    "openPipeline",
  ];
  for (const key of requiredNumeric) {
    if (!isFiniteNumber(b[key])) return { ok: false, error: `${key} is required and must be a number.` };
  }

  const optionalNumeric: Array<keyof ForecastAnalyzerInput> = [
    "bestCase",
    "weightedPipeline",
    "previousForecast",
    "previousActual",
    "historicalForecastAccuracyPct",
    "historicalWinRatePct",
    "historicalCommitAccuracyPct",
    "historicalSlippageRatePct",
    "avgSalesCycleDays",
    "avgOpportunityAgeDays",
    "daysRemainingInPeriod",
    "closeDatePushes",
    "numOpenOpportunities",
    "dealsInCommit",
    "top1DealValue",
    "top3DealsValue",
    "lateStagePipelineValue",
  ];
  for (const key of optionalNumeric) {
    if (!isNullableNumber(b[key] ?? null)) return { ok: false, error: `${key} must be a number or null.` };
  }

  const input: ForecastAnalyzerInput = {
    forecastPeriodLabel: (b.forecastPeriodLabel as string).trim(),
    revenueTarget: b.revenueTarget as number,
    closedRevenue: b.closedRevenue as number,
    currentForecast: b.currentForecast as number,
    commit: b.commit as number,
    openPipeline: b.openPipeline as number,
    bestCase: (b.bestCase as number | null) ?? null,
    weightedPipeline: (b.weightedPipeline as number | null) ?? null,
    previousForecast: (b.previousForecast as number | null) ?? null,
    previousActual: (b.previousActual as number | null) ?? null,
    historicalForecastAccuracyPct: (b.historicalForecastAccuracyPct as number | null) ?? null,
    historicalWinRatePct: (b.historicalWinRatePct as number | null) ?? null,
    historicalCommitAccuracyPct: (b.historicalCommitAccuracyPct as number | null) ?? null,
    historicalSlippageRatePct: (b.historicalSlippageRatePct as number | null) ?? null,
    avgSalesCycleDays: (b.avgSalesCycleDays as number | null) ?? null,
    avgOpportunityAgeDays: (b.avgOpportunityAgeDays as number | null) ?? null,
    daysRemainingInPeriod: (b.daysRemainingInPeriod as number | null) ?? null,
    closeDatePushes: (b.closeDatePushes as number | null) ?? null,
    numOpenOpportunities: (b.numOpenOpportunities as number | null) ?? null,
    dealsInCommit: (b.dealsInCommit as number | null) ?? null,
    top1DealValue: (b.top1DealValue as number | null) ?? null,
    top3DealsValue: (b.top3DealsValue as number | null) ?? null,
    lateStagePipelineValue: (b.lateStagePipelineValue as number | null) ?? null,
  };

  return { ok: true, input };
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return Response.json({ error: "Invalid JSON body." }, { status: 400 });
  }

  const parsed = parseInput(body);
  if (!parsed.ok) {
    return Response.json({ error: parsed.error }, { status: 400 });
  }

  const result = runForecastDiagnostic(parsed.input);

  try {
    const [row] = await db
      .insert(forecastAnalyses)
      .values({
        forecastPeriodLabel: parsed.input.forecastPeriodLabel,
        reliabilityScore: result.reliabilityScore,
        input: parsed.input,
        result,
      })
      .returning({ id: forecastAnalyses.id });

    return Response.json({ id: row.id, result }, { status: 201 });
  } catch (error) {
    console.error("Failed to persist forecast analysis", error);
    return Response.json({ error: "Failed to save the diagnostic. Please try again." }, { status: 500 });
  }
}
