"use client";

import { useState } from "react";
import Link from "next/link";
import { detectPipelineLeaks, type LeakDetectorResult } from "@/lib/pipeline-leak/engine";

const DEFAULT_STAGES = ["Qualified", "Proposal", "Negotiation", "Closed Won"];

export default function PipelineLeakDetectorPage() {
  const [values, setValues] = useState<string[]>(["", "", "", ""]);
  const [result, setResult] = useState<LeakDetectorResult | null>(null);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const stages = DEFAULT_STAGES.map((label, i) => ({ label, value: Number(values[i]) || 0 }));
    setResult(detectPipelineLeaks({ stages }));
  };

  return (
    <main className="mx-auto max-w-4xl px-4 py-12 sm:px-6">
      <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-blue-600">Kartik Clarity™ · Pipeline Leak Detector</p>
      <h1 className="mt-3 text-3xl font-semibold text-kc-navy-900 sm:text-4xl">Where is revenue leaking from the pipeline?</h1>
      <p className="mt-4 max-w-2xl text-sm leading-relaxed text-kc-navy-800/80">
        This instrument measures stage-to-stage attrition and quantifies revenue lost at each
        transition. It does not evaluate a forecast number; for forecast trustworthiness use{" "}
        <Link href="/forecast-analyzer" className="font-semibold text-kc-blue-600 underline">
          Forecast Analyzer™
        </Link>
        .
      </p>

      <form onSubmit={submit} className="mt-8 grid gap-4 rounded-2xl border border-kc-line bg-white p-6 sm:grid-cols-2">
        {DEFAULT_STAGES.map((label, i) => (
          <label key={label} className="flex flex-col gap-1 text-sm">
            <span className="font-medium text-kc-navy-900">{label} value ($)</span>
            <input
              type="number"
              value={values[i]}
              onChange={(e) => setValues((v) => v.map((x, idx) => (idx === i ? e.target.value : x)))}
              required
              className="rounded-md border border-kc-line px-3 py-2 text-sm focus:border-kc-blue-500"
            />
          </label>
        ))}
        <div className="sm:col-span-2">
          <button type="submit" className="rounded-md bg-kc-navy-900 px-5 py-3 text-sm font-semibold text-white hover:bg-kc-navy-800">
            Detect leaks
          </button>
        </div>
      </form>

      {result && (
        <section className="mt-10 rounded-2xl border border-kc-line bg-white p-6">
          <div className="flex flex-wrap items-baseline justify-between gap-3">
            <h2 className="text-lg font-semibold text-kc-navy-900">Funnel conversion</h2>
            <span className="text-3xl font-semibold kc-tabular text-kc-navy-900">
              {result.overallConversionPct !== null ? `${result.overallConversionPct.toFixed(1)}%` : "—"}
            </span>
          </div>

          <div className="mt-6 space-y-3">
            {result.transitions.map((t, i) => (
              <div
                key={i}
                className={`rounded-lg border p-4 ${
                  result.biggestLeak && t === result.biggestLeak ? "border-kc-red bg-kc-red-bg" : "border-kc-line"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-medium text-kc-navy-900">
                    {t.fromLabel} → {t.toLabel}
                  </span>
                  <span className="kc-tabular text-sm font-semibold text-kc-navy-900">{t.retainedPct.toFixed(1)}% retained</span>
                </div>
                <p className="mt-1 text-sm text-kc-navy-800/75">
                  ${t.leakedValue.toLocaleString()} leaked at this transition.
                  {result.biggestLeak && t === result.biggestLeak && " This is the largest leak point in the funnel."}
                </p>
              </div>
            ))}
          </div>

          <p className="mt-4 text-sm font-medium text-kc-navy-900">
            Total leaked value across the funnel: ${result.totalLeaked.toLocaleString()}
          </p>
        </section>
      )}
    </main>
  );
}
