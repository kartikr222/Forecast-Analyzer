import Link from "next/link";
import { KcBadgeLogo } from "@/components/brand/logo";

export default function HomePage() {
  return (
    <main>
      <section className="border-b border-kc-line bg-gradient-to-b from-kc-navy-950 via-kc-navy-900 to-kc-navy-800 text-white">
        <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 sm:px-6 md:grid-cols-[1fr_auto] md:items-center md:py-24">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-kc-cyan-300">Kartik Clarity™ · Revenue Diagnostics</p>
            <h1 className="mt-4 text-[clamp(2rem,5vw,3.4rem)] font-semibold leading-[1.08]">
              Three instruments. Three different questions. No overlap.
            </h1>
            <p className="mt-5 max-w-2xl text-base text-kc-cyan-100/90 sm:text-lg">
              Pipeline health, pipeline leakage, and forecast trustworthiness are not the same
              problem. Each diagnostic below answers exactly one of them, with evidence — not a
              questionnaire dressed up as analysis.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link
                href="/forecast-analyzer"
                className="rounded-md bg-kc-cyan-300 px-5 py-3 text-sm font-semibold text-kc-navy-900 transition-transform hover:scale-[1.02]"
              >
                Run Forecast Analyzer™
              </Link>
              <a
                href="#instruments"
                className="rounded-md border border-white/25 px-5 py-3 text-sm font-semibold text-white hover:bg-white/10"
              >
                Compare the three tools
              </a>
            </div>
          </div>
          <div className="hidden justify-self-center md:flex">
            <KcBadgeLogo size="lg" tag="Revenue Diagnostics" />
          </div>
        </div>
      </section>

      <section id="instruments" className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <h2 className="text-sm font-semibold uppercase tracking-[0.15em] text-kc-blue-600">The instrument family</h2>
        <div className="mt-6 grid gap-6 md:grid-cols-3">
          <ToolCard
            eyebrow="Pipeline Quality Scorer"
            question="How healthy and strong is the pipeline?"
            description="Scores the structural quality of what's currently open — stage mix, deal hygiene, activity evidence, and coverage shape — independent of what's being forecast to leadership."
            href="/pipeline-quality-scorer"
            status="Available"
          />
          <ToolCard
            eyebrow="Pipeline Leak Detector"
            question="Where is revenue leaking from the pipeline?"
            description="Finds where opportunities are dying — stage drop-off, stall points, disqualification patterns — and quantifies the revenue lost at each leak point."
            href="/pipeline-leak-detector"
            status="Available"
          />
          <ToolCard
            eyebrow="Forecast Analyzer™"
            question="How trustworthy is the forecast being reported to leadership?"
            description="Pressure-tests the number itself: what's evidence, what's assumption, what's exposed, and where this specific forecast is most likely to break."
            href="/forecast-analyzer"
            status="Flagship"
            highlight
          />
        </div>
      </section>

      <section className="border-t border-kc-line bg-kc-paper-dim">
        <div className="mx-auto max-w-6xl px-4 py-14 sm:px-6">
          <h2 className="text-2xl font-semibold text-kc-navy-900">Why forecast trust is a separate problem</h2>
          <p className="mt-4 max-w-3xl text-sm leading-relaxed text-kc-navy-800/90 sm:text-base">
            A pipeline can be structurally healthy and still produce a forecast leadership shouldn&apos;t
            trust this period. A pipeline can be leaking badly and still support a well-evidenced,
            conservative commit. Reliability, evidence, confidence, and revenue exposure are four
            different measurements — Forecast Analyzer™ is the only instrument in this family built
            to keep them separate instead of collapsing them into one comfortable score.
          </p>
        </div>
      </section>
    </main>
  );
}

function ToolCard({
  eyebrow,
  question,
  description,
  href,
  status,
  highlight,
}: {
  eyebrow: string;
  question: string;
  description: string;
  href: string;
  status: string;
  highlight?: boolean;
}) {
  return (
    <Link
      href={href}
      className={`group flex flex-col rounded-2xl border p-6 transition-shadow hover:shadow-lg ${
        highlight ? "border-kc-blue-500 bg-white shadow-md ring-1 ring-kc-blue-500/20" : "border-kc-line bg-white"
      }`}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold uppercase tracking-wide text-kc-blue-600">{eyebrow}</span>
        <span
          className={`rounded-full px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
            highlight ? "bg-kc-navy-900 text-white" : "bg-kc-paper-dim text-kc-navy-800"
          }`}
        >
          {status}
        </span>
      </div>
      <p className="mt-4 text-lg font-semibold leading-snug text-kc-navy-900">{question}</p>
      <p className="mt-3 flex-1 text-sm leading-relaxed text-kc-navy-800/80">{description}</p>
      <span className="mt-5 text-sm font-semibold text-kc-blue-600 group-hover:underline">Open diagnostic →</span>
    </Link>
  );
}
